/*
 *  testconv.cpp - conversion tests.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#include "sstring.h"
#include "nonstd.h"
#include "adamvector.h"
#include "adammatrix.h"
//#include "adamgenos.h"
#include "geno_f4.h"
#include "geno_f5.h"

#define NOTEST 1

char * gt3();

int main()
{
  //Rr, Qq, Cc, Ll, Ww, Ff, Aa, Ss, Mm, Ii, Ee
  #define NOEXAMPLES 15
  #define FIRSTEX 0
  #define LASTEX 14
  char gg[NOEXAMPLES][3][100] = {
    { "0 to test the existence of a stick",
      "/*4*/ X",
      "/*1*/ X" },
    { "1 to test two sticks joined together",
      "/*4*/ <X>X" ,
      "/*1*/ XX" },
    { "2 to test branching (two sticks joined to the same one)",
      "/*4*/ <<X>X>X" ,
      "/*1*/ X(X,X)" },
    { "3 to test branching angles (commas)",
      "/*4*/ <,<,,<,X,,>X>X>X" ,
      "/*1*/ X(,X,,,X,,X,,)" },
    { "4 more branching",
      "/*4*/ <X><X><<X>X><X>X" ,
      "/*1*/ XXX(XX,X)" },
    { "5 a more complex branching",
      "/*4*/ <<X><<X>X>X>X" ,
      "/*1*/ X(X,X(X,X))" },
    { "6 to test length factors",
      "/*4*/ <X>l<X>l<<X>X>LLLX",
      "/*1*/ XlXlX(LLLX,X)" },
    { "7 to test R branching rotation",
      "/*4*/ <<X>RR<<X>X>X>X" ,
      "/*1*/ X(X,RRX(X,X))" },
    { "8 to test C",
      "/*4*/ #3<X>lC>X",    // "/*4*/ <X>lC<X>lC<X>lCX"
      "/*1*/ XlCXlCXlCX" },
    { "9 to test existence of neurons",
      "/*4*/ <X><N[1:2]>N[-1:3]" ,
      "/*1*/ X[1:2][-1:3]" },
    { "10 to test bending muscle |",
      "/*4*/ <X><X><N|[1:2]>N[-1:3.5]",
      "/*1*/ XX[|1:2][-1:3.5]" },
    { "11 to test rotating muscle @ and giroscope sense G",
      "/*4*/ <X><<,<X,><N@[1:20]>N[G:30]>X>X",
      "/*1*/ XX[@1:20][G:30](X,,X,)" },
    { "12 to test muscles",
      "/*4*/ <X>N|[*:1][G:2]" ,
      "/*1*/ X[|*:1,G:2]" },
    { "13 to test duplicating links upon neuron division",
      "/*4*/ <X>N<[*:0]>[-1:10]<>",
      "/*1*/ X[*:0][-1:10][-2:10]" },
    { "14 to test neural links",
      //"/*4*/ <X><<N|[0:1]>X><N@[-1:1.2][1:2.3]><N[G:1]>X",
      "/*4*/ <X><<X>N|[0:1]><X><N@[-1:1.2][1:2.3]>N[G:1]",
      "/*1*/ XX[|0:1]X[@-1:1.2,1:2.3][G:1]" }
  };

  int i;

  sstring buf0;
  sstring buf1;
  char * ingeno;
  int ret0, ret1;

  for (i=FIRSTEX; i<=LASTEX; i++) {
    printf("example %i\n", i);
    printf("%s\n", gg[i][0]);
    ingeno = gg[i][1];
    printf("%s \n", ingeno);
    ret0 = geno_conv(ingeno, 0, buf0);
    ret1 = geno_conv(ingeno, 1, buf1);
    if (ret1) printf("      %s", (char*)buf1); 
      else printf("error! %d", ret1);
    if (!strcmp(buf1, gg[i][2]+6)) printf("  (good)"); else printf("  BAD!");
    printf("\n");
    printf("%s  (given)\n\n", gg[i][2]);
    if (ret0) printf("%s\n\n", (char*)buf0); 
      else printf("error! %d\n", ret0);
  }

  return 0;
}

char * gt3()
{
  return
"/*3*/ 20 \n"
" 3 0  1.3874 13  9  3  8 0  7.1113 15  5  6  6 1  8.8682 11  6  1"
" 1 0  0.5579  9 14  3  3 0  1.0125 10  6  8 12 0  3.1606  0 14  2"
"12 1  7.2044  5  6  7  3 1  1.0229  2  9  4 15 0  9.9774 15  5 11"
" 2 0  2.6505 11  6  6\n"
" 8 1  3.2740 10 12 12"
" 2 0  7.2504 12  5  5"
"15 1  0.6660  6  5  7"
" 2 1  0.6788 13  7 12"
" 1 1  9.8103  1 12  3"
" 0 1  3.4736  2  3  5"
" 3 0  3.0530  2 11 12"
" 0 0  4.6294 10  5  7"
"10 0  9.1531 10 11 14"
"10 1  6.8274 13 11 11"
;}

