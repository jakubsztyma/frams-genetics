#ifndef _SSTRING_H_
#define _SSTRING_H_

#include <string.h>
#include <stdlib.h>

class sstring
{
private:
  char *txt;
  void nowy(char*);
  void nowy(int);
public:
  unsigned int d;  // adam, orig:  int d;
  sstring(char*t) {nowy(t);}
  sstring(int x=0) {nowy(x);}
  ~sstring() {free(txt);}
operator char*() {return txt;}
char& operator[](int i) {return txt[i];}
void operator=(char*t) {
  if (strlen(t)<=d) strcpy(txt,t);
  else {free(txt);nowy(t);}
}  // adam, orig:
// void operator=(char*t) {free(txt);nowy(t);}
void shrink(void) {char *tmp=txt; nowy(tmp); free(tmp); }
void operator=(int x) {free(txt);nowy(x);}
void operator+=(int x);
void operator+=(char*);
void operator+=(sstring&);
void operator=(sstring &s) {free(txt);nowy(s.txt);}
int operator==(sstring &s) {return !strcmp(txt,s.txt);}
//char operator[](int p) {return txt[p];}
char* operator()(int p) {return txt+p;}
};

#endif
