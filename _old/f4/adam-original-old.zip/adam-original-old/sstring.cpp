#include "sstring.h"

void sstring::nowy(char*t)
{
if (t) {nowy(strlen(t)); strcpy(txt,t);}
else nowy(0);
}
void sstring::nowy(int x)
{
d=x;
txt=(char*)malloc(x+1);
memset(txt,' ',d);
txt[d]=0;
}
void sstring::operator+=(int x)
{
if (!x) return;
char *t=(char*)malloc(x+d+1);
strcpy(t,txt);
memset(t+d,' ',x);
d+=x;
free(txt);
txt=t;
txt[d]=0;
}

void sstring::operator+=(char *s)
{
if (!s) return;
int x=strlen(s);
if (!x) return;
unsigned int nl=strlen(txt)+x;
if (nl<=d) { strcat(txt, s); return; }
txt=(char*)realloc(txt, nl+8+1);
d=nl+8;
strcat(txt,s);
txt[d]=0;
} /* adam, orig:
void sstring::operator+=(char *s)
{
if (!s) return;
int x=strlen(s);
if (!x) return;
char *t=(char*)malloc(d+1+x);
strcpy(t,txt);
strcpy(t+d,s);
d+=x;
free(txt);
txt=t;
txt[d]=0;
}*/

void sstring::operator+=(sstring&s)
{
if (!s.d) return;
char *t=(char*)malloc(d+1+s.d);
strcpy(t,txt);
strcpy(t+d,s);
d+=s.d;
free(txt);
txt=t;
txt[d]=0;
}
