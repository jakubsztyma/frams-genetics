/*
 *  testf4.cpp - f4 testing program.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#include "geno_f4.h"
#include "nonstd.h"
#include "sstring.h"

void testf4mut(char * origgeno);
void testf4validate(char * geno);


void printf4(char * geno)
{
  printf("f4 geno '%s'\n", geno);
}


void f4mutprint(char *& geno, float &chg)
{
  printf4(geno);

  TGeno_f4 F4;

  if (F4.Mutate( geno, chg) != GENOPER_OK)
    printf(" error in mutation!\n");
  else
    printf(" after mutation: '%s'\n", geno);
}


void f4crossprint(char *& g1, char *& g2, float chg1, float chg2)
{
  printf4(g1);
  printf4(g2);

  TGeno_f4 F4;

  if (F4.CrossOver( g1, g2, chg1, chg2) != GENOPER_OK)
    printf(" error in crossover!\n");
  else {
    printf(" after cross 1: '%s'\n", g1);
    printf(" after cross 2: '%s'\n", g2);
  }
}


void f4checkprint(char * geno)
{
  int res;
  TGeno_f4 tf4;

  printf4(geno);
  res = tf4.Check( geno );

  if (res<=0) {
    switch (res) {
    case GENOPER_OK:	 printf(" check: OK.\n"); break;
    case GENOPER_OPFAIL: printf(" check: invalid\n"); break;
    case GENOPER_REPAIR: printf(" check: invalid, repairable\n"); break;
    default:		 printf(" check: ??\n");
    }
  }
  if (res>0) printf(" check: error at pos %d ('%c')\n", res, geno[res-1]);
}


void f4validate(char *& geno)
{
  int res;
  TGeno_f4 tf4;

  res = tf4.Validate( geno );

  if (res<=0) {
    switch (res) {
    case GENOPER_OK:	 printf(" validate: OK\n"); break;
    case GENOPER_OPFAIL: printf(" validate: invalid, could not fix\n"); break;
    case GENOPER_REPAIR: printf(" validate: repaired to '%s'\n", geno); break;
    default:		 printf(" validate: ??\n");
    }
  }
  if (res>0) printf(" validate: error at pos %d ('%c')\n", res, geno[res-1]);
}


void testf4_mutate(char * origgeno)
{
  char * buf;
  int i;
  float chg = 0.2f;

  buf = (char*) malloc( strlen(origgeno)+500 ); // slack
  strcpy(buf, origgeno);

  for (i=0; i<7; i++) {
    strcpy(buf, origgeno);
    f4mutprint(buf, chg);
  }

  for (i=0; i<40; i++) {
    f4mutprint(buf, chg);
  }
 
  // check final one (just to be sure)
  f4checkprint(buf);

  // convert final genotype in f0
  sstring out0;
  Convert_f4_to_f0( buf, out0);
  printf("\n\n%s\n", (char*)out0);

  free(buf);
}


void f4checkvalidateprint(char * geno)
{
  char * buf;
  buf = (char*) malloc( strlen(geno)+500 );  // slack
  strcpy(buf, geno);
  f4checkprint(buf);
  f4validate(buf);
  free(buf);
}


void testf4_crossover()
{
  char * buf1;
  char * buf2;
  buf1 = (char*) malloc( 200 );
  buf2 = (char*) malloc( 200 );

  strcpy(buf1, "lX");
  strcpy(buf2, "LX");
  f4crossprint(buf1, buf2, 0.2f, 0.5f);

  // buf1/2 might have been shrinked! realloc
  buf1 = (char*) realloc( buf1, 300 );
  buf2 = (char*) realloc( buf2, 300 );
  strcpy(buf1, "<<lllXllllll>llllXlllll><lllllXllll>llllllXlll");
  strcpy(buf2, "<<LLLXLLLLLL>LLLLXLLLLL><LLLLLXLLLL>LLLLLLXLLL");
  f4crossprint(buf1, buf2, 0.2f, 0.5f);

  // buf1/2 might have been shrinked! realloc
  buf1 = (char*) realloc( buf1, 300 );
  buf2 = (char*) realloc( buf2, 300 );
  strcpy(buf1, "l<l<l<<X><<<X>X>X><X><X>X>X>ll<<<<lX><,<X>l,<lX><<X>X>X>X>X>X>lX><X>X");
  strcpy(buf2, "L<L<L<<X><<<X>X>X><X><X>X>X>LL<<<<lX><,<X>L,<LX><<X>X>X>X>X>X>LX><X>X");
  f4crossprint(buf1, buf2, 0.2f, 0.5f);

  // check final one (just to be sure)
  f4checkprint(buf1);
  f4checkprint(buf2);

  free(buf2);
  free(buf1);
}


void testf4_check_validate()
{
  // this should be ok
  f4checkvalidateprint( "X"   ); 
  // redundant X, remove
  f4checkvalidateprint( "XlX" ); 
  // unknown code
  f4checkvalidateprint( "XZ"  );
  // mutation of X, cannot repair
  f4checkvalidateprint( "X<X>");
  // multiple redundant Xs, remove more than one
  f4checkvalidateprint( "XXlX");
  // undiff. cell
  f4checkvalidateprint( "<>X");
  // stray starting ,
  f4checkvalidateprint( ",X");
  // muscle on undiff
  f4checkvalidateprint( "@");
  // muscle on X
  f4checkvalidateprint( "X|");
  // two neural control modifiers
  f4checkvalidateprint( "<X>N@|");
  // this should be OK
  f4checkvalidateprint( "<X>N@");
  // bad neuron
  f4checkvalidateprint( "<X>N[3]");
  // link without neuron
  f4checkvalidateprint( "<X[G:3]>X");
  // multiple errors
  f4checkvalidateprint( "<X><XLl|,L<X><N>X>X");
  // some harmless whitespace
  f4checkvalidateprint( "<\tX  >\nX  ");
  // missing > can be fixed
  f4checkvalidateprint( "<X");
  // two neurons, should be ok
  f4checkvalidateprint( "<X><N[1:10]>N[-1:20]");
  // neurons with out of bounds reference
  f4checkvalidateprint( "<X><N[2:10]>N[-3:20]");
  // neurons with out of bounds reference
  f4checkvalidateprint( "<X><N[1:10]><X>N[-1:20]");
  // rep with no number
  f4checkvalidateprint( "#l>X");
}

#include "unistd.h"
int main(int argn, char ** argc)
{
  int i;

  testf4_check_validate();
  // repeat tests
  for (i=0; i<100; i++) {
    printf("testf4 run %d\n", i);
    testf4_mutate("X");
    testf4_crossover();
  }
  return 0;
}
