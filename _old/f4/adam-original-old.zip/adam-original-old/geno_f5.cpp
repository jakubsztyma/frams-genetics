/* 
 * geno_f5.cpp - f5 format genotype conversions.
 * 2000.4.2.  2000.1.19.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
2000.4.2.    celle4 0.1.4
2000.1.15.   celle3 0.1.3

 - there is a limit an organism age
 - cell adhesiveness is dependent on a chemical (1)
 - local interaction intensity is mediated by a chemical (2)
 - organism must be connected (unconnected cells are pruned)
 - the ultimate fitness is organism size (over x)
 - when a new cell created, concentrations are from the environment
    with fluctuation (rather then completely random) 
*/

#include "geno_f5.h"


int Convert_f5_to_f0(char *in, sstring &out) 
{
  // build organism from genotype
  Organism5 Org(in);
  Org.simulate();
  
  out = "";
  Org.to0(out);
  return 1;	// ok
}

int Convert_f5(char *in, int outformat, sstring &out) 
{
  // converts to '0'
  if (0!=outformat) return 0;
  return Convert_f5_to_f0(in, out);
}


void mutate_5(char * in, sstring &out)
{
  Rules R(in);
  R.mutate(&commonSeed);
  out = "";
  R.write(out);
}


//--- util.cpp ---

/**********
 * myRand *
 **********
 * own random number generation. portable and guaranteed, from Numerical Receipes
 */
#define RND0_IA 16807
#define RND0_IM 2147483647
#define RND0_AM (1.0f/RND0_IM)
#define RND0_IQ 127773
#define RND0_IR 2836
#define RND0_MASK 123459876
/* 
 * "Minimal" random number generator of Park and Miller.
 * Returns a uniform random deviate between 0.0 and 1.0.
 * Numerical Receipes, page 279.
 * http://www.ulib.org/webRoot/Books/Numerical_Recipes
 */
float myRand(long * seed)
{
	long k;
	float ans;

	*seed ^= RND0_MASK;
	k=(*seed)/RND0_IQ;
	*seed=RND0_IA*(*seed-k*RND0_IQ)-RND0_IR*k;
	if (*seed < 0) *seed += RND0_IM;
	ans=RND0_AM*(*seed);
	*seed ^= RND0_MASK;
	return ans;
}
// return a random seed, based on the current time
long randomTimeSeed()
{
	#ifdef UNIX
	return (long)(3l + (long)time(NULL) % 56789l);
	#else
	return 666;
	#endif
}
long commonSeed = 1l;	// a global seed


/*********
 * FRand *
 *********/
float FRand(float rmin, float rmax, long *seed)
{
	return rmin + myRand(seed) * (rmax-rmin);
}

/*********
 * VRand *
 *********/
Vector VRand(float rmin, float rmax, long *seed)
{
	float xx, yy, zz;
	xx = FRand(rmin,rmax, seed);
	yy = FRand(rmin,rmax, seed);
	zz = FRand(rmin,rmax, seed);
	return Vector(xx, yy, zz);
}


// --- chemical.cpp

Chemicals::Chemicals()
{
  int i;
  for (i=0; i<NUMCHEM; i++) {
    c[i] = delta[i] = 0;
  }
  sum = 0;
}


Chemicals::Chemicals(float scale, long * seed)
{
  int i;
  for (i=0; i<NUMCHEM; i++) {
    c[i] = scale * myRand(seed);
    delta[i] = 0;
  }
  computeSum();
}


void Chemicals::write(FILE * f)
{
  int i;
  for (i=0; i<NUMCHEM; i++)
    fprintf(f, "%.3f ", c[i]);
  fprintf(f, "  tot: %.3f\n", sum);
}


void Chemicals::computeSum()
{
  int i;
  sum = 0;
  for (i=0; i<NUMCHEM; i++)
    sum += c[i];
}


void Chemicals::update()
{
  int i;
  for (i=0; i<NUMCHEM; i++) {
    c[i] += delta[i];
    if (c[i]<CHEM_MIN) c[i]=CHEM_MIN;
    #ifdef CHEM_MAXLIMIT
    if (c[i]>CHEM_MAX) c[i]=CHEM_MAX;
    #endif
    delta[i] = 0;
  }
  computeSum();
}


// --- cell.cpp ---

// a brand new cell
Cell::Cell(Organism5 * nO, int nname, Vector npos)
{
  int i;
  name = nname;
  dead = 0;
  O = nO;
  // initialize position
  len = 0.5f;
  Vector dir = VRand(-2, 2, &(O->seed)).Normalized() * (0.5f * len);
  pos[0] = npos + dir;
  pos[1] = npos - dir;
  vel[0] = vel[1] = Vector(0,0,0);

  // initialize chemical concentrations
  c = new Chemicals();
  for (i=0; i<NUMCHEM; i++)
    c->c[i] = O->chem->c[i] * (1.1f * CONST_Fluct *(myRand(&(O->seed))-0.5f));
  // print chems
  //c->write(stdout);
  dns = 0;

  printf("Cell %d created\n", name);
}


// create new cell by halving an existing one
Cell::Cell(Cell * c0, int nname, Vector npos0, Vector npos1)
{
  name = nname;
  dead = 0;
  O = c0->O;
  pos[0] = npos0;
  pos[1] = npos1;
  vel[0] = vel[1] = Vector(0,0,0);   
  len = (pos[0]-pos[1]).Magnitude();   
  c = new Chemicals();   
  dns = 0;

  printf("%6.1f Cell %d created\n", O->time, name);
}


Cell::~Cell()
{ }


void Cell::write(FILE * f)
{
  fprintf(f, "cell %d pos (%g,%g,%g) len: %g\t dns: %.2f\n", 
    name, pos[0].x, pos[0].y, pos[0].z, len, dns);
}


void Cell::vTick()
{
  if (dead) return;

  int i, j;
  Vector f[2], ff;

  dns += O->dt * CONST_F * c->c[CHEM_DNS];
  
  // update reaction matrix
  for (i=0; i<NUMCHEM; i++)
    for (j=0; j<NUMCHEM; j++)
      rm[i][j] = -1;
  // process rules
  Rule * r1;
  for (i=0; i<O->R->nrule; i++) {
    // check rule
    r1 = O->R->r[i];
    if (r1->isActive(c)) {
      //printf("rule %d is active\n", i);
      rm[ r1->to ][ r1->from0 ] = r1->from1;
    }
  }   
  // print matrix
  if (0) {
    for (j=0; j<NUMCHEM; j++) printf(" %2d", j);
    printf("\n");
    for (i=0; i<NUMCHEM; i++) {
      for (j=0; j<NUMCHEM; j++)
        if (rm[i][j] >= 0) printf(" %2d", rm[i][j]);
                      else printf("  .");
      printf("\n");
    }
  }

  // forces
  f[0] = f[1] = Vector(0,0,0);

  // compute changes in chemical concentrations
  float deltac, delta2, fact, len0, len1, sprcon;
  Cell * clink;
  Link link1;
  Vector cpos;
  int whichfrom, whichto;
  for (i=0; i<NUMCHEM; i++) {

    deltac = 0;

    // metabolic reactions
    for (j=0; j<NUMCHEM; j++) {
      if (rm[i][j] >= 0) {
        deltac += mfun( c->c[j] * c->c[ rm[i][j] ] );
      }
      if (rm[j][i] >= 0) {
        deltac -= mfun( c->c[ rm[j][i] ] * c->c[j] );
      }
    }

    // active transport to environment (Transp)
    delta2 = CONST_P * tfun( c->sum, O->chem->c[i] );

    // diffusion to environment (Diff)
    delta2 += CONST_D * ( O->chem->c[i] - c->c[i] );
    deltac += delta2;
    // reduce chemicals in environment
    //U->getChem()->delta[i] -= CONST_Edump * delta2;

    // local interactions
    for (j=0; j<O->links.n; j++) {
      link1 = O->links.l[j];
      clink = NULL;
      if (this == link1.cell[0]) { 
        clink = link1.cell[1]; 
        whichto = link1.wend[1];
        whichfrom = link1.wend[0];
      }
      else if (this == link1.cell[1]) {
        clink=link1.cell[0]; 
        whichto = link1.wend[0];
        whichfrom = link1.wend[1];
      }
      if (NULL != clink) {
      
        // local diffusion
        fact =  (0.5f + log(c->c[CHEM_LOCAL]+1.0f));
        deltac += CONST_DL * fact * ( clink->c->c[i] - c->c[i] );

        // local active transport
        deltac += CONST_PL * fact * tfun( c->sum, clink->c->c[i] );

        // links
        cpos = clink->pos[ whichto ];
        len = (pos[ whichfrom ]- cpos).Magnitude();
        fact =  (0.5f + log(c->c[CHEM_LINK]+1.0f));
        len0 = CONST_Len0 * fact;
        len1 = CONST_LenBrF * len0;
        sprcon = CONST_SK0 / fact;
        // break if too long
        if (len > len1) {
//printf("connection broken %d - %d %g\n", this->name,clink->name, len);
          O->removeLink(this, clink);
        } else {
          ff = (cpos - pos[ whichfrom ]).Normalized() * 
            (sprcon * (len - len0));
          f[whichfrom] += ff;
        }
      }
    }

    c->delta[i] = deltac * O->dt;
  }

  // update concentrations at once
  c->update();

  // check for conditions (division & death)
  if (c->sum < CONST_S) {
    dns = 0; // cannot divide
    #ifdef CELL_DEATH
    die();
    #endif
  }

  if (dns > CONST_R) divide();

  len = (pos[0]-pos[1]).Magnitude();
  // own elastic force
  ff = (pos[1]-pos[0]) * (CONST_SK0 * (len - CONST_Len0));
  f[0] += ff;
  f[1] -= ff; 
  // brownian movement
  f[0] += VRand(-CELL_BROWN, CELL_BROWN, &(O->seed));
  f[1] += VRand(-CELL_BROWN, CELL_BROWN, &(O->seed));
 
  // move
  f[0]   -= vel[0] * O->dt;
  vel[0] = vel[0] * CONST_Slow + f[0] * O->dt;
  pos[0] += vel[0] * O->dt;
  f[1]   -= vel[1] * O->dt;
  vel[1] = vel[1] * CONST_Slow + f[1] * O->dt;
  pos[1] += vel[1] * O->dt;

  //c->write(stdout);
}


void Cell::die()
{
  if (dead) return;
  printf("%6.1f Cell %d dies dns %.2f\n", O->time, name, dns);
  // release chemicals
  //for (i=0; i<NUMCHEM; i++)
  //  U->getChem()->delta[i] += CONST_Edump * c->c[i];
  O->removeCell(this);
}


void Cell::divide()
{
  int i;
  Vector breakpoint;

  if (O->isFull()) {
    die();
    return;
  }

  //c->write(stdout);
  printf("%6.1f Cell %d divides, act: %.2f\n", O->time, name, c->sum);

  // reset this cell
  dns = 0;

  breakpoint = (pos[0]+pos[1])*0.5f + VRand(-0.02f, 0.02f, &(O->seed));

  // create daughter cell
  Cell * newcell = new Cell(this, O->cellCount, breakpoint, pos[1]);
  if (O->addCell(newcell)) {  // error
    delete newcell;
    return;
  }
  O->cellCount++;
  pos[1] = breakpoint;

  // halve chemical concentrations
  for (i=0; i<NUMCHEM; i++) {
    newcell->c->c[i] = c->c[i] * (0.5f + CONST_Fluct*(myRand(&(O->seed))-0.5f));
             c->c[i] = c->c[i] * (0.5f + CONST_Fluct*(myRand(&(O->seed))-0.5f));
  }
  // duplicate links
  Link link1;
  for (i=0; i<O->links.n; i++) {
    link1 = O->links.l[i];
    if (this == link1.cell[0])
      O->addLink(link1.wend[0], newcell,       link1.wend[1], link1.cell[1]);
    if (this == link1.cell[1])
      O->addLink(link1.wend[0], link1.cell[0], link1.wend[1], newcell);
  }

  // add link between the two cells, links are akways symmetric
  O->addLink(1, this, 0, newcell);
}


// --- rule.cpp ---

Rule::Rule(
  chemical  ntrigger,
  short int ncompare,
  float     ntresh,
  chemical  nfrom0,
  chemical  nfrom1,
  chemical  nto)
{
  trigger = ntrigger;
  compare = ncompare;
  tresh   = ntresh;
  from0   = nfrom0;
  from1   = nfrom1;
  to      = nto;
}


Rule::Rule()
{
  Rule::Rule(0, 0, 0.0f, 0, 0, 0);
}


Rule::Rule(long * seed)
{
  trigger = (chemical)(NUMCHEM * myRand(seed));
  compare = (myRand(seed) < 0.5f) ? 0 : 1;
  tresh   = 10.0f * myRand(seed);
  from0   = (chemical)(NUMCHEM * myRand(seed));
  from1   = (chemical)(NUMCHEM * myRand(seed));
  to      = (chemical)(NUMCHEM * myRand(seed));
}


Rule::Rule(Rule * nR)
{
  trigger = nR->trigger;
  compare = nR->compare;
  tresh   = nR->tresh;
  from0   = nR->from0;
  from1   = nR->from1;
  to      = nR->to;
}


void Rule::write(FILE * f)
{
  fprintf(f, "%2d %c %8.5f --> %2d -> (%2d %2d)\n",
    trigger, compare ? '<' : '>', tresh, from0, from1, to);
}


void Rule::write(char * s)
{
  sprintf(s, "%2d %1d %8.5f %2d %2d %2d\n",
    trigger, compare, tresh, from0, from1, to);
}


int Rule::isActive(Chemicals * conc)
{
  int active=0;
  if (!compare) { //  <
    if (conc->c[trigger] < tresh) active=1;
  } else {
    if (conc->c[trigger] > tresh) active=1;
  }
  return active;
}


void Rule::mutate(long * seed)
{
  // mutate components with probabilities
  // 0.15  0.05  0.35  0.15  0.15  0.15
  float prob = myRand(seed);

  prob -= 0.15;
  if (prob<=0) {
    trigger = (chemical)(NUMCHEM * myRand(seed));
    return;
  }
  prob -= 0.05;
  if (prob<=0) {
    compare = (myRand(seed) < 0.5f) ? 0 : 1;
    return;
  }
  prob -= 0.35;
  if (prob<=0) {
    // mutate threshold additively
    tresh   = tresh + 0.4f*(myRand(seed)-0.5f);
    return;
  }
  prob -= 0.15;
  if (prob<=0) {
    from0   = (chemical)(NUMCHEM * myRand(seed));
    return;
  }
  prob -= 0.15;
  if (prob<=0) {
    from1   = (chemical)(NUMCHEM * myRand(seed));
    return;
  }
  prob -= 0.15;
  if (prob<=0) {
    to      = (chemical)(NUMCHEM * myRand(seed));
    return;
  }
}



Rules::Rules(int nnrules, long * seed)
{
  int i;  
  nrule = nnrules;
  if (nrule>=NUMRULES-1) nrule=NUMRULES-1;
  for (i=0; i<nrule; i++)
    r[i] = new Rule(seed);
}


Rules::Rules(char * s)
{
  // parse rules from string
  nrule = 0;
  int pos = 0;
  int len = strlen(s);
  int nr = 0;
  int mod = -1, tmp;
  char buf[80];
  while (1) {
    // parse into words
    buf[0]=0;
    while ((' '==s[pos]) || ('\n'==s[pos]) && (pos<len)) pos++;
    if (pos>=len) break;
    while ((' '!=s[pos]) && ('\n'!=s[pos]) && (pos<len)) {
      buf[strlen(buf)+1]=0;
      buf[strlen(buf)] = s[pos++];
    }
    //printf("-< %s >-\n", buf);
    if ((0==nrule) && (-1==mod)) {
      // first number is no
      sscanf(buf, "%d ", &nr);
      if (nr>NUMRULES-1) nr=NUMRULES-1;
      mod=0;
    } else {
      if (0==mod) {
         r[nrule] = new Rule();
         if (1!=sscanf(buf, "%d", &tmp)) printf("!! %d\n", mod);
         r[nrule]->trigger = tmp;
         mod++;
      } else if (1==mod) {
         sscanf(buf, "%d", &tmp);
         r[nrule]->compare = tmp;
         mod++;
      } else if (2==mod) {
         sscanf(buf, "%f", &(r[nrule]->tresh));
         mod++;
      } else if (3==mod) {
         sscanf(buf, "%d", &tmp);
         r[nrule]->from0 = tmp;
         mod++;
      } else if (4==mod) {
         sscanf(buf, "%d", &tmp);
         r[nrule]->from1 = tmp;
         mod++;
      } else if (5==mod) {
         sscanf(buf, "%d", &tmp);
         r[nrule]->to = tmp;
         mod=0;
         if (nrule<NUMRULES-1) nrule++;
         if (nrule>=nr) break;		// all read
      }
    }
    if (pos>=len) break;
  }
  //write(stdout);
}


Rules::Rules(Rules * nR)
{
  int i;
  nrule = nR->nrule;
  for (i=0; i<nrule; i++)
    r[i] = new Rule( nR->r[i] );
}


void Rules::write(FILE * f)
{
  int i;
  for (i=0; i<nrule; i++)
    r[i]->write(f);
}

  
void Rules::write(char * s)
{
  int i;
  sprintf(s, "%d\n", nrule);
  for (i=0; i<nrule; i++)
    r[i]->write(s + strlen(s) );
}


void Rules::mutate(long * seed)
{
  // 0.05:  duplicate a rule
  // 0.05:  delete a rule
  // 0.90:  mutate a rule
  float prob = myRand(seed);
  // select one rule
  int idx = (int)( nrule * myRand(seed) );
  int i;
  prob -= 0.05f;
  if (prob<=0) {
    // duplicate the rule, if there is room
    if (nrule<NUMRULES-1) {
      r[nrule] = new Rule(r[idx]);
      nrule++;
printf("rule duplicated! %d\n", nrule);
    }
  }
  prob -= 0.05f;
  if (prob<=0) {
    // delete a rule
    if (nrule>1) {
      nrule--;
      for (i=idx; i<nrule; i++)
        r[i] = r[i+1];
    }
  }
  // else mutate the rule
  r[idx]->mutate(seed);
}


// --- organism.cpp ---

void Links::write(FILE * f)
{
  int i;
  if (!n) return;
  fprintf(f, "%d conns  \n", n);
  for (i=0; i<n; i++) {
    fprintf(f, "  %d[%d]-%d[%d] (%g) \n", 
      (l[i].cell[0]) ? l[i].cell[0]->name : -1, 
      l[i].wend[0],
      (l[i].cell[1]) ? l[i].cell[1]->name : -1,
      l[i].wend[1],
      (l[i].cell[0]->pos[ l[i].wend[0] ] - l[i].cell[1]->pos[ l[i].wend[1] ])
      .Magnitude() );
  }
}


void Links::add(short int ne0, Cell * nc0, short int ne1, Cell * nc1)  
{
  if (n >= MAXLINKS-1) return;
  l[n].wend[0] = ne0;
  l[n].cell[0] = nc0;
  l[n].wend[1] = ne1;
  l[n].cell[1] = nc1;
  n++;
};


int Links::remove(Cell * from) 
{
  int i, j, nre=0;
  for (i=0; i<n; i++) {
    if (from == l[i].cell[0]) l[i].cell[0]=NULL;
    if (from == l[i].cell[1]) l[i].cell[0]=NULL;
  }
  // repack
  for (i=0; i<n; i++) 
    if (NULL == l[i].cell[0]) {
      n--;
      nre++;
      for (j=i; j<n; j++)  l[j]=l[j+1];
      i--;
    }
  return nre;
}


int Links::remove(Cell * from, Cell * to) 
{
  int i, j, nre=0;
  for (i=0; i<n; i++) {
    if (from == l[i].cell[0]) 
      if (to == l[i].cell[1]) l[i].cell[0]=NULL;
    if (from == l[i].cell[1]) 
      if (to == l[i].cell[0]) l[i].cell[0]=NULL;
  }
  // repack
  for (i=0; i<n; i++) 
    if (NULL == l[i].cell[0]) {
      n--;
      nre++;
      for (j=i; j<n; j++)  l[j]=l[j+1];
      i--;
    }
  return nre;
}



Organism5::Organism5()
{
  // initialize rules
  R = new Rules(NUMRULES, &seed);
  init();
}


Organism5::Organism5(Rules * nR)
{
  R = nR;
  init();
}


Organism5::Organism5(char * genot)
{
  R = new Rules(genot);
  init();
}


Organism5::~Organism5() {};


void Organism5::init()
{
  seed = 1l;
  dead = 0;
  chem = new Chemicals(CONST_S / NUMCHEM * 2.0f, &seed);

  // create a cell
  cellCount=0;
  ncell=0;
  Cell * c0 = new Cell(this, cellCount, Vector(0,0,0) );
  cellCount++;
  maxage = 0;
  addCell(c0);

  dt = 0.05f;
  time = 0.0f;
  ticks = 0l;
  bornt = time;
  //R->write(stdout);
  //printf("org initialized with %d rules\n", R->nrule);
}


void Organism5::write(FILE * f)
{
  int i;
  fprintf(f, "org %d cells, %d conns, age %.2f:\n", 
    ncell, links.n, time-bornt);
  for (i=0; i<ncell; i++)
    cell[i]->write(f);
  links.write(f);
}


void Organism5::vTick()
{
  int i, j;

  // check age
  if (time - bornt >= maxage) die();

  for (i=0; i<ncell; i++) {
    if (!(cell[i]->dead))
      cell[i]->vTick();
  }

  // remove dead cells (only first)
  Cell * deadc;
  for (i=0; i<ncell; i++)
    if (cell[i]->dead) {
      deadc = cell[i];
      ncell--;
      for (j=i; j<ncell; j++)
        cell[j] = cell[j+1];
    }

  time += dt;
  ticks++;

  if (ncell <= 0) die();
}


// stand-alone simulation of this organism.
// to be used in genotype decoding, with no Universe around
void Organism5::simulate()
{
  init();

  // do steps, will die eventually
  while (!dead) {
    vTick();
  }

  printf("simulation of org stopped, t=%.1f\n", time);
}


float Organism5::fit()
{
  float fit;

  if (ncell<1) return 0;

  //if (ncell>=5) {
  //  // compute extent over x
  //  int i;
  //  float minx, maxx;
  //  minx = 1e10; maxx = -1e10;
  //  for (i=0; i<ncell; i++) {
  //    if (cell[i]->pos[0].x < minx) minx=cell[i]->pos[0].x;
  //    if (cell[i]->pos[0].x > maxx) maxx=cell[i]->pos[0].x;
  //  }
  //  return 200 + 10*(maxx-minx);
  //}

  if ((f0nstick>1) || (f0nneuron>0)) {
    fit = 100 + f0nstick + f0nneuron;
    // extra term to encourage both
    if ((f0nstick>0) &&  (f0nneuron>0))  {
      fit += 0.2f*f0nstick*f0nneuron;
      if ((f0nstick>1) &&  (f0nneuron>0))  
        fit += 0.8f*f0nstick*f0nneuron;
    }
    return fit;
  }

  //if (ncell>1) {
  //  //fit = 100 + ncell;
  //  fit = 100 + ncell + 0.5f*(1.0f-(time-bornt)/MAXAGE2);
  //  return fit;
  //}

  fit = cell[0]->c->sum;
  //fit = cell[0]->dns
  //fit = cell[0]->dns + cell[0]->c->sum;

  return (fit < 20) ? fit : 20;
}


int Organism5::addCell(Cell * nC)
{
  if (ncell >= MAXCELLS-1) return -1;
  cell[ncell] = nC;
  ncell++;
  maxage = (time-bornt)+MAXAGE1;
  if (maxage>MAXAGE2) maxage=MAXAGE2;
  return 0;
}


int Organism5::isFull()
{
  if (ncell >= MAXCELLS-1) return 1;
  return 0;
}


void Organism5::removeCell(Cell * C)
{
  // mark cell dead, will be removed in next tick
  C->dead = 1;
  // remove links
  removeLink(C);
}


void Organism5::addLink(short int ne0, Cell * nc0, short int ne1, Cell * nc1)
{
  links.add(ne0, nc0, ne1, nc1);
}


void Organism5::removeLink(Cell * from)
{
  if (links.remove(from))
    pruneCells();
}
void Organism5::removeLink(Cell * from, Cell * to)
{
  if (links.remove(from, to))
    pruneCells();
}


void Organism5::pruneCells()
{
  int i, j, idx, flagq;
  short int connq[MAXCELLS];
  short int lc[MAXLINKS][2];

  // translate link Cell pointers to indeces
  for (i=0; i<links.n; i++) {
    idx=links.n-1;
    for (j=0; j<ncell; j++)
      if (links.l[i].cell[0] == cell[j]) idx=j;
    lc[i][0] = idx;
    idx=links.n-1;
    for (j=0; j<ncell; j++)
      if (links.l[i].cell[1] == cell[j]) idx=j;
    lc[i][1] = idx;
  }
 
  // find out which cells are connected to cell[0]
  for (i=0; i<ncell; i++)  connq[i]=0;
  connq[0]=1;
  do {
    flagq = 0;
    for (i=0; i<links.n; i++) {
      if ((connq[ lc[i][0] ] + connq[ lc[i][1] ]) == 1) {
        // one is connected, one is not
        //if (connq[ lc[i][0] ])  {  // make it stronger: directional
        if ((connq[ lc[i][0] ]) && (0==links.l[i].wend[1])) {
          if (!connq[ lc[i][1] ]) { connq[ lc[i][1] ]=1; flagq=1; }
        }
        if ((connq[ lc[i][1] ]) && (0==links.l[i].wend[0])) {
          if (!connq[ lc[i][0] ]) { connq[ lc[i][0] ]=1; flagq=1; }
        }
      }
    }
  } while (flagq);
  
  if (0 && (ncell>1)) {
    printf("The following cells are not connected (%d):\n", ncell);
    for (i=0; i<ncell; i++)
      if (!connq[i]) printf("%d ", cell[i]->name);
    printf("\n");
  }

  // remove unconnected cells
  for (i=0; i<ncell; i++)
    if (!connq[i]) 
      links.remove(cell[i]);
  for (i=0; i<ncell; i++)
    if (!connq[i]) 
      cell[i]->die();

  // and halt development
  die();
} 


void Organism5::die()
{
  if (dead) return;
  dead = 1;
  printf("Organism dies at age %.1f\n", time - bornt);
}


void Organism5::to0(sstring &out)
{
  if (ncell<=0) return;
  int i;

  // first, decide cell types
  for (i=0; i<ncell; i++) {
    cell[i]->type = T_UNDIFF5;
  }

  // decide if stick or neuron
  for (i=0; i<ncell; i++) {
    if (cell[i]->c->c[CHEM_STICKT] >	//goodway
        cell[i]->c->c[CHEM_NEURONT])
      cell[i]->type = T_STICK5;
    else
      cell[i]->type = T_NEURON5;
  }

  // make cell[0] always a stick
  cell[0]->type = T_STICK5;

  // print out celltypes
  printf("celltypes:\n");
  for (i=0; i<ncell; i++) {
    printf("%d\t%d\n", cell[i]->name, cell[i]->type);
  }

  // write out endpoints and sticks
  f0nendpo = 0;
  f0nstick = 0;
  f0nneuron = 0;
  // initialize sticks
  for (i=0; i<ncell; i++) {
    cell[i]->visitq = 0;
    cell[i]->ordno = -1;
    cell[i]->closest  = NULL;
    cell[i]->endpo[0] = NULL;
    cell[i]->endpo[1] = NULL;
  }
  // traverse first to get some parameters right (endpo.mass)
  // traverse everything connected to cell[0]
  if (T_STICK5 == cell[0]->type)
    tof0stick(cell[0], 0, out);
  if (T_NEURON5 == cell[0]->type)
    tof0neuron(cell[0], 0, out);

  // traverse for the 2nd time, output
  for (i=0; i<ncell; i++) {
    cell[i]->outputq = 0;
    if (T_STICK5 == cell[i]->type) {
      if (cell[i]->endpo[0])
        cell[i]->endpo[0]->outputq = 0; 
      if (cell[i]->endpo[0])
        cell[i]->endpo[1]->outputq = 0; 
    }
  }
  out = "";
  out = "/*0*/\n";  // version
  if (T_STICK5 == cell[0]->type)
      tof0stick(cell[0], 1, out);
  if (T_NEURON5 == cell[0]->type)
      tof0neuron(cell[0], 1, out);
}


void Organism5::tof0endpo(Cell * c, int whichend, int output, sstring &out)
{
  endpoint **p1;
  char       buf[200];
  int        i;
  Link       ll;

  if (T_STICK5 != c->type) {
    printf(" error: cell %d is not stick!\n", c->name);
    return;
  }
  p1 = &(c->endpo[whichend]);
printf(" endpo cell %d:%d\n", c->name, whichend);
  if (NULL == *p1) {  
      // this endpo was not processed yet.
      // create, merge
      *p1 = new endpoint;
      // get a number for this end
      // just informative, real numbering after join, before out
      (*p1)->ordno = c->name + 1000*whichend;
      (*p1)->x = c->pos[whichend].x;
      (*p1)->y = c->pos[whichend].y;
      (*p1)->z = c->pos[whichend].z;
      (*p1)->m = 1.0f;
      (*p1)->sumpos = c->pos[whichend];
      (*p1)->count = 1;
      // find closest link (if any), link to it
      float mindist, dist;
      endpoint ** p2;
      p2 = NULL; mindist=1e10;
      for (i=0; i<links.n; i++) {
        ll = links.l[i];
        if (c == ll.cell[0]) 
        if (whichend == ll.wend[0])
        if (T_STICK5 == ll.cell[1]->type) {
          tof0stick(ll.cell[1], output, out);
          dist = (c->pos[whichend] - ll.cell[1]->pos[ll.wend[1]]).Magnitude();
          if (dist < mindist) 
            { mindist=dist; p2=&(ll.cell[1]->endpo[ll.wend[1]]); }
        }
        if (c == ll.cell[1])  
        if (whichend == ll.wend[1])
        if (T_STICK5 == ll.cell[0]->type) {
          tof0stick(ll.cell[0], output, out);
          dist = (c->pos[whichend] - ll.cell[0]->pos[ll.wend[0]]).Magnitude();
          if (dist < mindist) 
            { mindist=dist; p2=&(ll.cell[0]->endpo[ll.wend[0]]); }
        }
      }
      if (p2)
      if (NULL != *p2) {
        // **p1 and **p2 should be joined
printf("endpo join %d:%d\n", c->name, whichend);
        // only if it is different than my other endpoint
        if (c->endpo[!whichend] != *p2) 
          tof0joinEnds(p1, p2);
        else {
          printf("oops! two endpoints the same! %d\n", c->name);
        }
      }
    // recursively visit all connected sticks
    for (i=0; i<ncell; i++) {
        if ( cell[i]->endpo[0] == *p1 )
        if (c != cell[i]) {
printf(" go to %d\n", cell[i]->name);
          tof0stick(cell[i], output, out);
        }
        if ( cell[i]->endpo[1] == *p1 )
        if (c != cell[i]) {
printf(" go to %d\n", cell[i]->name);
          tof0stick(cell[i], output, out);
        }
    }
  }
  // output it:
  if (output) {
    if (NULL == (*p1)) { printf("error: p1 null\n"); return; }
    if (!(*p1)->outputq) {
      (*p1)->outputq = 1;
      // get a number for it
      (*p1)->ordno = f0nendpo;
      f0nendpo++;
      //matrix33 M;
      //M.printox(out);
      (*p1)->m = (*p1)->count;
      (*p1)->sprint(buf, 200);
      out += buf;
printf("out endpo %d cell %d:%d\n", (*p1)->ordno, c->name, whichend);
    }
    // recursively visit all connected sticks
    for (i=0; i<ncell; i++) {
        if ( cell[i]->endpo[0] == *p1 )
        if (c != cell[i]) {
printf(" go to %d\n", cell[i]->name);
          tof0stick(cell[i], output, out);
        }
        if ( cell[i]->endpo[1] == *p1 )
        if (c != cell[i]) {
printf(" go to %d\n", cell[i]->name);
          tof0stick(cell[i], output, out);
        }
    }
  }
}


void Organism5::tof0stick(Cell * c, int output, sstring &out)
{
  char     buf[200];
  stick    s1;
  int      i;
  Link     ll;

  if (T_STICK5 != c->type) {
    printf(" error: cell %d is not stick!\n", c->name);
    return;
  }
  if (!c->visitq) {
    c->visitq = 1;
    // visit two endpoints
    tof0endpo(c, 0, output, out);
    tof0endpo(c, 1, output, out);
    // recursively visit connected neurons
    for (i=0; i<links.n; i++) {
      ll = links.l[i];
      if (c == ll.cell[0]) 
      if (T_NEURON5 == ll.cell[1]->type)
        tof0neuron(ll.cell[1], output, out);
      if (c == ll.cell[1])  
      if (T_NEURON5 == ll.cell[0]->type)
        tof0neuron(ll.cell[0], output, out);
    }
  }
  if (output) {
    s1.reset();
    if (!c->outputq) {
      c->outputq = 1;
      // make sure it is outputted already
      // visit two endpoints
      tof0endpo(c, 0, output, out);
      tof0endpo(c, 1, output, out);
      s1.p1 = c->endpo[0]->ordno;	// one end
      s1.p2 = c->endpo[1]->ordno;	// other end
      if (s1.p1 != s1.p2) {
        // get a number for this
        c->ordno = f0nstick;
        f0nstick++;
        // output this stick:
        s1.sprint(buf, 200);
        out += buf;
printf("out stick %d cell %d %s", c->ordno, c->name, buf);
        // recursively visit connected neurons
        for (i=0; i<links.n; i++) {
          ll = links.l[i];
          if (c == ll.cell[0]) 
          if (T_NEURON5 == ll.cell[1]->type)
            tof0neuron(ll.cell[1], output, out);
          if (c == ll.cell[1])  
          if (T_NEURON5 == ll.cell[0]->type)
            tof0neuron(ll.cell[0], output, out);
        }
      } else {
          printf("oops! two stick endpoints the same! %d\n", c->name);
      }
    }
  }
}


void Organism5::tof0neuron(Cell * c, int output, sstring &out)
{
  char     buf[200];
  neuron   n1;
  Cell *   clos2;
  int i;
  Link ll;

  if (T_NEURON5 != c->type) {
    printf(" error: cell %d is not neuron!\n", c->name);
    return;
  }
  if (!c->visitq) {
    c->visitq = 1;
    // try to find closest stick
    if (NULL == c->closest) {
      c->closest = tof0findClosest(c, 1, T_STICK5);
      if (NULL == c->closest) {
        c->closest = tof0findClosest(c, 0, 0);
        // should be stick
        while ((NULL!=c->closest) && (T_STICK5!=c->closest->type)) {
          clos2 = tof0findClosest(c->closest, 1, T_STICK5);
          if (NULL == clos2)
            clos2 = tof0findClosest(c->closest, 0, 0);
          c->closest = clos2;
        }
      }
    }
printf(" neu cell %d par %d\n", c->name, (NULL==c->closest)?-1:c->closest->name);

    // recursively visit all connected neurons
    for (i=0; i<links.n; i++) {
      ll = links.l[i];
      if (c == ll.cell[0]) 
        if (T_NEURON5 == ll.cell[1]->type)
          tof0neuron(ll.cell[1], output, out);
      if (c == ll.cell[1])  
        if (T_NEURON5 == ll.cell[0]->type) 
          tof0neuron(ll.cell[0], output, out);
    }
  }
  if (output) {
    n1.reset();
    if (!c->outputq) {
      c->outputq = 1;
      n1.est = -1;
      if (NULL != c->closest) {
        n1.est = c->closest->ordno;	// one end on parent1
      } else {	// no parent, ignore
      }
      if (n1.est >= 0) {
        // get a number for this neuron
        c->ordno = f0nneuron;
        f0nneuron++;
        // for now, make it bending QQ
        n1.ctrl = 1;
        // output this neuron:
        n1.sprint(buf, 200);
        out += buf;
printf("out neu %d cell %d %s", c->ordno, c->name, buf);
        // for now, add a constant input
        sprintf(buf, "inp:%d, 1, 100\n", c->ordno);
        out += buf;
      }

      // recursively visit all connected neurons
      for (i=0; i<links.n; i++) {
        ll = links.l[i];
        if (c == ll.cell[0]) 
          if (T_NEURON5 == ll.cell[1]->type)
            tof0neuron(ll.cell[1], output, out);
        if (c == ll.cell[1])  
          if (T_NEURON5 == ll.cell[0]->type) 
            tof0neuron(ll.cell[0], output, out);
      }
    }
  }
}


Cell * Organism5::tof0findClosest(Cell * c, int onetype, int type)
{
  // find closest cell attached to this 
//  if (NULL != c->closest) return;  // already has
  int i;
  Cell * clos = NULL;
  float mindist=1e10, dist;
  Link ll;
  for (i=0; i<links.n; i++) {
    ll = links.l[i];
    if (c == ll.cell[0]) 
    if (0 == ll.wend[0]) 
    if ((!onetype) || (onetype && (ll.cell[1]->type == type))) {
      dist = (c->pos[ ll.wend[0] ] - ll.cell[1]->pos[ ll.wend[1]]).Magnitude();
      if (dist < mindist) { mindist=dist; clos=ll.cell[1]; }
    }
    if (c == ll.cell[1])
    if (0 == ll.wend[1])
    if ((!onetype) || (onetype && (ll.cell[0]->type == type))) {
      dist = (c->pos[ ll.wend[1] ] - ll.cell[0]->pos[ ll.wend[0]]).Magnitude();
      if (dist < mindist) { mindist=dist; clos=ll.cell[0]; }
    }
  }
printf(" cell %d parent %d\n", c->name, (NULL==clos)?-1:clos->name);
  return clos;
}


void Organism5::tof0joinEnds(endpoint ** p1, endpoint ** p2)
{
  int i;
  if (NULL==p1) { printf("error! p1 null\n"); return; }
  if (NULL==p2) { printf("error! p2 null\n"); return; }
  if (NULL==(*p1)) { printf("error! *p1 null\n"); return; }
  if (NULL==(*p2)) { printf("error! *p2 null\n"); return; }
  if ((*p1) == (*p2)) return;	// they are the same!
printf("join %d %d\n", (*p1)->ordno, (*p2)->ordno);
  endpoint * p3;
  // create new record
  p3 = new endpoint;
  // new averaged position
  p3->sumpos = (*p1)->sumpos + (*p2)->sumpos;
  p3->count  = (*p1)->count  + (*p2)->count;
  p3->ordno  = (*p1)->ordno;  // informative only
  // new positions:
  if (p3->count>0) {
    p3->x = p3->sumpos.x / p3->count;
    p3->y = p3->sumpos.y / p3->count;
    p3->z = p3->sumpos.z / p3->count;
  } else {
    p3->x = p3->y = p3->z = 0;
  }
  // delete old records
  endpoint * old1 = *p1;
  endpoint * old2 = *p2;
  delete (*p1);
  delete (*p2);
  // make both point to the new
  for (i=0; i<ncell; i++)
    if (T_STICK5 == cell[i]->type) {
      if (cell[i]->endpo[0]) {
      if (cell[i]->endpo[0] == old1)  cell[i]->endpo[0]=p3;
      if (cell[i]->endpo[0] == old2)  cell[i]->endpo[0]=p3;
      }
      if (cell[i]->endpo[1]) {
      if (cell[i]->endpo[1] == old1)  cell[i]->endpo[1]=p3;
      if (cell[i]->endpo[1] == old2)  cell[i]->endpo[1]=p3;
      }
    }
}
