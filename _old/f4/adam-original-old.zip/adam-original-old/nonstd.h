/*
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#ifndef NONSTD_H
#define NONSTD_H

// when building your code into framsticks, the
// following macro is defined:
// #define MAIN_FRAMSTICKS
// it is NOIT defined here.

#define DB(x) x
//#define DB(x) 

//genetic operators
#define GENOP_CHECK        1
#define GENOP_VALIDATE     2
#define GENOP_MUTATE       3
#define GENOP_CROSSOVER    4
#define GENOP_SIMILARITY   5

#define GENOPER_OK          0 //operation successful
#define GENOPER_REPAIR     -1 //only for Check() in GenMan and for
                              //Check() & Validate() in classes TGeno_fx
#define GENOPER_NOOPER     -2 //no suitable operator for this genotype format
#define GENOPER_OPFAIL     -3 //operation could not be completed

//gene/character styles (for Style method)
#define GENSTYLE_NONE       0 //no style specified (=normal font)
#define GENSTYLE_INVALID    1 //this char cannot be accepted
#define GENSTYLE_BOLD       2 //bold
#define GENSTYLE_ITALIC     4 //italic
//#define GENSTYLE_UNDERLINE  -  reserved to mark errors
#define GENSTYLE_STRIKEOUT  8 //strikeout (not recommended)

#define GENRGB(r,g,b) ((unsigned long)(((unsigned char)(r)|((unsigned short)((unsigned  char)(g))<<8))|(((unsigned long)(unsigned char)(b))<<16)))
#define GENSTYLE_RGBS(r,g,b,s) ((unsigned long)((unsigned char)s)<<24 | GENRGB(r,g,b))
#define GENSTYLE_CS(rgb,s) ((unsigned long)((unsigned char)s)<<24 | rgb)

#define GENGETSTYLE(style) ((style)>>24)
#define GENGETCOLOR(style) ((style)&0x00ffffff)

//recommended colors to use
#define GENCOLOR_TEXT    GENRGB(0,0,0)
#define GENCOLOR_NUMBER  GENRGB(200,0,0)

extern void FramMessage(char *classname, char *method,
  char *errtxt, int wght);
// Use this function
// to send messages to the "debug" window.
// example: FramMessage("GenMan","SkipWS","NULL reference!",2);
//                     ^class   ^method  ^message         ^priority
// Priorities:
// 0 - information
// 1 - warning
// 2 - error (perhaps corrected)
// 3 - critical error (the simulation will be stopped and
//     the user should re-start the program)

// You may use the following functions:
//void GenMan::SkipWS(char *&p); //advances pointer p skipping whitespaces
//int GenMan::Compare(char*,char*); //compares any two text strings skipping whitespaces.
//                                  //returns 0 when equal, 1 when different.

// and a random generator RndGen, may be useful for you:
//class RandomGener
//{
//   public:
//      RndGen() {JestNastGauss=0; return 0;}
//      static double Uni(float pocz, float kon)
//         {return pocz+(double)rand()*(kon-pocz)/RAND_MAX;}
//      double GaussStd();
//      double Gauss(float m,float s) {return m+s*GaussStd();} //not more than 5*stdd
//}; //extern RandomGener RndGen;

// For geno versions and comments use funcs
//int ver=genkonwmanager::wersjagenow(geny);
// get version
//char *g2=genkonwmanager::ominkomentarz(geny);
// skip comment
class genkonwmanager {
public:
  // to tell the format of genotype and
  static char wersjagenow(char *geno);

  // to skip the beginning comment.
  static char * ominkomentarz(char *geno);
};
//extern genkonwmanagerObj genkonwmanager;


// and rename your files to "geno_conv_20" etc. (means f2 to f0).
// and rename your files to "Convert_f2_to_f0" etc. (means f2 to f0).

// mother of all TGeno_fx classes
class TGeno_fx
{
public:
};

//In your class, you may implement the following functions:
//class TGeno_f3
//{
// public:
//   int Validate(char *);
//    returns error position (1-based), GENOPER_OKwhen geno is OK,
//    GENOPER_REPAIR if errors were fixed
//   int Check(char *);
//    returns error position (1-based), GENOPER_OKwhen geno is OK,
//    GENOPER_REPAIR if errors and validation is possible
//   int Mutate(char *&g,float& chg);
//    returns GENOPER_OK or GENOPER_OPFAIL
//    chg: fraction of changed genes in child (from 0 to 1)
//   int CrossOver(char *&g1,char *&g2,float& chg1,float& chg2);
//    returns GENOPER_OK or GENOPER_OPFAIL
//    chg1: fraction of parent1 genes in child1 (parent2 has the rest)
//    chg2: fraction of parent2 genes in child2 (parent1 has the rest)
//   float Similarity(char*,char*); //0..1 lub -1 jesli zly format
//    returns normalized similarity of genotypes (1: identical, 0: different)

//   unsigned long Style(char *g, int pos); //returns Style (and validity)
// of the genotype char g[pos]. Assume white background.
// now you can test for the context of a char.

//   int Style(char,unsigned long&color,unsigned long &style);
//    color, style (and validity) of a char. Assume white background.
//   ...
//};

#endif

