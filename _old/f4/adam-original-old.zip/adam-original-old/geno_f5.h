/*
 *  geno_f5.h - f5 format genotype conversions.
 *  2000.4.16.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

/*
  2000.1.15.   celle3 0.1.3

 - there is a limit an organism age
 - cell adhesiveness is dependent on a chemical (1)
 - local interaction intensity is mediated by a chemical (2)
 - organism must be connected (unconnected cells are pruned)
 - the ultimate fitness is organism size (over x)
 - when a new cell created, concentrations are from the environment
    with fluctuation (rather then completely random) 
 2000.1.15.
*/

#ifndef GENO_F5_H
#define GENO_F5_H

#include <stdio.h>
#include "adamvector.h"
#include "adamgenos.h"
#include "sstring.h"


int Convert_f5(char * in, int outformat, sstring &out);
int Convert_f5_to_f0(char * in, sstring &out);

void mutate_5(char * in, sstring &out);


// --- util.h ---

#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef HUGE_FLOAT
  #define HUGE_FLOAT 1.0e37f
#endif
#ifndef TINY_FLOAT
  #define TINY_FLOAT 1.0e-37f
#endif
#ifndef ABS
 #define ABS(x) (((x)>0) ? (x) : (-(x)))
#endif

/**********
 * myRand *
 **********
 * own random number generation. portable and guaranteed, 
 * from Numerical Receipes
 */
float myRand(long * seed);
long randomTimeSeed();
extern long commonSeed;	// a global seed

/***************
 * FRand/VRand *
 ***************
 * FRand Returns a random floating point number between rmin and rmax
 * VRand Returns a random Vector whose compoents are between rmin and rmax
 */
float FRand(float rmin, float rmax, long *seed);
Vector VRand(float rmin, float rmax, long *seed);


// --- chemical.h ---

#define NUMCHEM 16
typedef short int chemical;
#define CHEM_MAXLIMIT
#define CHEM_MIN 1e-8f
#define CHEM_MAX 100.0f


class Chemicals {
public:
  Chemicals();
  Chemicals(float scale, long * seed);
  void write(FILE * f);
  void computeSum();
  void update();

  float c[NUMCHEM];	// chemical concentrations
  float delta[NUMCHEM];	// change in chemical concentration
  float sum;
};


// --- cell.h ---

class Organism5;

//#define CELL_DEATH	no cell death in f5!

#define CONST_P      0.1f
#define CONST_D      0.05f
#define CONST_PL     0.1f
#define CONST_DL     0.1f
#define CONST_R     10.0f
#define CONST_F      0.4f
#define CONST_S      2.0f
#define CONST_X     15.0f
//#define CONST_delt   1.0f
#define CONST_Vmax  10.0f
#define CONST_Kmax   5.0f
#define CONST_Fluct  0.0001f
#define CONST_Len0   0.5f
#define CONST_LenBrF 2.0f
#define CONST_SK0    1.0f
#define CONST_Slow  0.96f
#define CELL_BROWN   0.2f

#define CHEM_DNS	0	// chemical producing dna
#define CHEM_LINK	1	// inter-cell link strength
#define CHEM_LOCAL	2	// local cell interaction strngth
#define CHEM_STICKT	3	// cell type: stick marking chem
#define CHEM_NEURONT	4	// cell type: neuron marking chem


class Cell {
public:
  Cell(Organism5 * nO, int nname, Vector npos);
  Cell(Cell * c0, int nname, Vector npos0, Vector npos1);
  virtual ~Cell();
  void         write(FILE * f);
  virtual void vTick();

  int         name;
  int         dead;
  Chemicals * c;
  Organism5 * O;
  Vector      pos[2];
  Vector      vel[2];
  float       len;
  float       dns;
  void die();

  // these are for the f0 genotype conversion:
  int        visitq, outputq;
  int        type;
  int        ordno;
  endpoint*  endpo[2];
  Cell *     closest;
private:
  void divide();
  
  chemical    rm[NUMCHEM][NUMCHEM];	// reaction matrix
};


inline float mfun(float s)
{
  return (CONST_Vmax * s) / (CONST_Kmax + s);
}

inline float tfun(float a, float x)
{
  float denom = 0.5f*x + a;
  // avoid div by 0
  if (ABS(denom)<1e-8) denom=1e-8;
  return (a * x) / denom;
}


// --- rule.h ---

class Rule {
public:
  Rule(chemical, short int, float, chemical, chemical, chemical);
  Rule();
  Rule(long * seed);
  Rule(Rule * nR);
  void  write(FILE * f);
  void  write(char * s);
  int   isActive(Chemicals * conc);
  void  mutate(long * seed);

  chemical  trigger;
  short int compare;
  float     tresh;
  chemical  from0;
  chemical  from1;
  chemical  to;
};


// number of metabloic rules in a genotype
#define NUMRULES 50

class Rules {
public:
  Rules(int nnrule, long * seed);
  Rules(Rules * nR);
  Rules(char * s);
  void  write(FILE * f);
  void  write(char * s);
  void  mutate(long * seed);

  Rule * r[NUMRULES];
  int  nrule;
};


// --- organism.h ---

#define MAXLINKS 120
#define MAXCELLS 40
#define MAXAGE1 80
#define MAXAGE2 320

class Link {
public:
  short int wend[2];
  Cell *    cell[2];
};

class Links {
public:
  Links() { n=0; };
  void write(FILE * f);
  void add(short int ne0, Cell * nc0, short int ne1, Cell * nc1);
  int  remove(Cell * from);
  int  remove(Cell * from, Cell * to);
  Link l[MAXLINKS];
  int n;
private:
};


class Organism5 {
public:
  Organism5();
  Organism5(Rules * nR);
  Organism5(char * genot);
  virtual ~Organism5();
  void    init();
  void    write(FILE * f);
  virtual void vTick();
  void    simulate();
  float   fit();
  int     addCell(Cell * nC);
  int     isFull();
  void    removeCell(Cell * C);
  void    addLink(short int ne0, Cell * nc0, short int ne1, Cell * nc1);
  void    removeLink(Cell * from);
  void    removeLink(Cell * from, Cell * to);
  void    pruneCells();
  void    die();

  // these are for the f0 genotype conversion
  void to0(sstring &out);

  Rules * R;
  Links   links;
  long    cellCount;
  float	  time;
  float   dt;
  long    ticks;
  Chemicals * chem;
  long    seed;
private:
  Cell *  cell[MAXCELLS];
  int     ncell;
  int     dead;
  float   bornt;
  float   maxage;

  // these are for the f0 genotype conversion
  int f0nendpo, f0nstick, f0nneuron;
  void   tof0endpo(Cell * c, int output, int whichend, sstring &out);
  void   tof0stick(Cell * c, int output, sstring &out);
  void   tof0neuron(Cell * c, int output, sstring &out);
  Cell * tof0findClosest(Cell * c, int onetype, int type);
  void   tof0joinEnds(endpoint ** p1, endpoint ** p2);
};


#endif
