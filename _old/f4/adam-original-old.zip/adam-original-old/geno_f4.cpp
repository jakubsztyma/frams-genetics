/*
 * geno_f4.cpp - f4 genotype functions.
 * 2000.6.30.  1999.11.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "nonstd.h"
#include "geno_f4.h"


extern void FramMessage(char*, char*, char*, int);

#ifdef MAIN_FRAMSTICKS

static TGeno_f4 *GENO4param_GENO4=0;
#define GENO4OFF(XXX) (long)((char*)(&GENO4param_GENO4-> XXX)-(char*)GENO4param_GENO4)

static param_entry GENO4param_tab[]=
{
{"Genetics: f4",1,5,},
{"geno_f4_mut1add", 0, 0, "Add node", "f 0 1", GENO4OFF(mut1add), 
  "mutation: probability of adding a node", },
{"geno_f4_mut1del", 0, 0, "Delete node", "f 0 1",GENO4OFF(mut1del),
  "mutation: probability of deleting a node", },
{"geno_f4_mutAdd2div", 0, 0, "Add division", "f 0 1",GENO4OFF(mutadd2div),
  "add node mutation: probability of adding a division", },
{"geno_f4_mutAdd2link", 0, 0, "Add link", "f 0 1",GENO4OFF(mutadd2link),
  "add node mutation: probability of adding a link", },
{"geno_f4_mutAdd2rep", 0, 0, "Add repetition", "f 0 1",GENO4OFF(mutadd2rep),
  "add node mutation: probability of adding a repetition", },
{0,},
};

#endif


int Convert_f4(char * in, int outformat, sstring &out) 
{
  int res;
  // converts to '0' or '1'
  if ((0!=outformat) && (1!=outformat)) return 0;

  char buf[100];
  sprintf(buf, "from f4 geno of len. %d to f%d", strlen(in), outformat);
  FramMessage("-", "Convert_f4", buf, 0);

  // build organism
  Organism Org;
  res = Org.buildfrom4( in );
  if (GENOPER_OK != res) return 0;  // oops
  
  // print out into 0 (or 1)
  //DB( Org.print(); )
  out = 300;
  out = "";
  if (0==outformat) Org.to0(out);
  if (1==outformat) Org.to1(out);
  return 1;	// ok
}

int Convert_f4_to_f0(char *in, sstring &out) 
{ return Convert_f4(in, 0, out); }

int Convert_f4_to_f1(char *in, sstring &out) 
{ return Convert_f4(in, 1, out); }


TGeno_f4::TGeno_f4() 
#ifdef MAIN_FRAMSTICKS
        : par(GENO4param_tab, this)
#endif
{
  mut1add     = 0.50;
  mut1del     = 0.20;
  // rest change node
  mutadd2div  = 0.20;
  mutadd2link = 0.20;
  mutadd2rep  = 0.10;
  // rest add simple
}

int TGeno_f4::ValidateRec(f4node * geno, int retrycount)
{
  // ! the genotype is geno->child (not geno) !
  // build from it with repair on
  Organism Org;
  int res = Org.buildfrom4( geno, 1 );
  // errors not fixed:
  if (GENOPER_OPFAIL == res) {
    if (Org.geterrorpos() >= 0) return 1+Org.geterrorpos();
    return GENOPER_OPFAIL;
  }
  // errors fixed:
  if (GENOPER_REPAIR == res) {
    // note: geno might have been fixed
    // check again
    int res2 = GENOPER_OK;
    if (retrycount>0) 
      res2 = ValidateRec( geno, retrycount-1 );
    
    if (res2==GENOPER_OK) return GENOPER_REPAIR;
    return res2;
  }
  // no errors:
  return GENOPER_OK;
}

int TGeno_f4::Validate(char *& geno)
{ 
  // convert geno to tree, then try to validate a couple of times
  f4node * root;
  int res;
  root = new f4node();
  res = processf4rec(geno, 0, root);
  if (res) {
    goto retv;  // errorpos
  }
  if (1 != root->childCount()) {
    res = GENOPER_OPFAIL;
    goto retv;
  }

  res = ValidateRec( root, 20 ); 
  // if repaired, make it back to string
  if (GENOPER_REPAIR==res) {
    geno[0]=0;
    root->child->sprintAdj(geno);
  }

retv:
  // release memory
  delete root;

  return res;
}


int TGeno_f4::Check(char * geno)
{
  // try to validate it, see if it's OK or repairable
  // copy it, because Validate might make changes
  char * buf;
  buf = (char *) malloc( strlen(geno)+200 ); // slack
  strcpy(buf, geno);
  int res = Validate(buf);
  free(buf);
  return res;
}


int TGeno_f4::MutateOne(f4node *& g, float &chg)
{
  // ! the genotype is g->child (not g) !
  // a mutation is:
  // - mut1add (0.75)  add new node
  //   - mutadd2div (0.20)  add division ('<')
  //   - mutadd2link (0.20)  add link ('[...]')
  //   - mutadd2rep (0.10)  add repet ('#n')
  //   - rest  add simple node
  //     - 1/n each: add one of ",lLXN@|" ...
  // - mut1del (0.25)  delete node
  // - rest  mutate node
  // codes that can be changed (apart being added/deleted)
  #define MUT_CHAN_CODES "<[#"
  #define ADD_SIMPLE_CODES ",lLcCrRXN@|"
  #define REP_MAXCOUNT 19

  f4node * n1, * n2, * n3;
  float prob, prob2, prob3;
  int i, j;

  // do the mutation
  // pick a random node
  n1 = g->child->randomNode();
  //DB( printf("%c\n", n1->name); )
  prob = 1.0f / RAND_MAX * rand();
  prob -= mut1add;
  if (prob < 0) {
    // add a node
    // simple codes that can be added: ADD_SIMPLE_CODES
    prob2 = 1.0f / RAND_MAX * rand();
    prob2 -= mutadd2div;
    if (prob2 < 0) {
      // add division ('<')
      n3 = n1->parent;
      n3->removeChild(n1);
      n2 = new f4node('<', n3, n3->pos );
      n2->addChild(n1);
      // new cell is stick or neuron
      // "X>" or "N>"
      prob3 = 1.0f / RAND_MAX * rand();
      prob3 -= 0.5f;
      if (prob3<0) n3 = new f4node('X', n2, n2->pos);
      else {
      prob3 -= 0.5f;
      if (prob3<0) n3 = new f4node('N', n2, n2->pos);
      }
      new f4node('>', n3, n3->pos);
      n1->parent = n2;
      // now with 50% chance swap children
      prob3 = 1.0f / RAND_MAX * rand();
      if (prob3 < 0.5f) {
        n3 = n2->child;
        n2->child = n2->child2;
        n2->child2 = n3;
      }
    } else {
    prob2 -= mutadd2link;
    if (prob2 < 0) {
      // add link
      n1->parent->removeChild(n1);
      n2 = new f4node('[', n1->parent, n1->parent->pos);
      linkNodeMakeRandom(n2);
      n2->addChild(n1);
      n1->parent = n2;
    } else {
    prob2 -= mutadd2rep;
    if (prob2 < 0) {
      // add repetition ('#')
      // repeated code (left child) is empty, count is 2
      n3 = n1->parent;
      n3->removeChild(n1);
      n2 = new f4node('#', n3, n3->pos );
      n2->i1 = 2;
      new f4node('>', n2, n2->pos);
      n2->addChild(n1);
      n1->parent = n2;
    } else {
      // add simple node
      // choose a simple node from ADD_SIMPLE_CODES
      j = strlen(ADD_SIMPLE_CODES);
      n1->parent->removeChild(n1);
      prob3 = ((float)j) / RAND_MAX * rand();
      for (i=0; i<j-1; i++) {
        prob3 -= 1.0f;
        if (prob3 < 0) break;
      }
      n2 = new f4node(ADD_SIMPLE_CODES[i], n1->parent, n1->parent->pos );
      n2->addChild(n1);
      n1->parent = n2;
    }}}
  } else {
  prob -= mut1del;
  if (prob < 0) {
    // delete a node
    // must pick a node with parents
    // already picked a node, but repeat may be needed
    for (i=0; i<10; i++) {
      if ((NULL != n1->parent) && (g != n1->parent)) break;
      // try a new one
      n1 = g->child->randomNode(); 
    }
    if ((NULL != n1->parent) && (g != n1->parent)) {
      if (0 == n1->childCount()) {
        // no child
        n2 = n1->parent;
        n2->removeChild(n1);
      }
      if (1 == n1->childCount()) {
        // one child
        n2 = n1->parent;
        n2->removeChild(n1);
        if (NULL != n1->child) {
          n1->child->parent = n2; 
          n2->addChild(n1->child);
          n1->child = NULL; 
        }
        if (NULL != n1->child2) {
          n1->child2->parent = n2;
          n2->addChild(n1->child2);
          n1->child2 = NULL; 
        }
      }
      if (2 == n1->childCount()) {
        // two children
        n2 = n1->parent;
        n2->removeChild(n1);
        // n1 has two children. pick one randomly 50-50, destroy other
        prob2 = 1.0f / RAND_MAX * rand();
        if (prob2 < 0.50f) {
          n1->child->parent = n2; 
          n2->addChild(n1->child);
          n1->child = NULL;
          n1->child2->parent = NULL;
        } else {
          n1->child2->parent = n2; 
          n2->addChild(n1->child2);
          n1->child2 = NULL;
          n1->child->parent = NULL;
        }
      }
      // destroy n1
      n1->parent=NULL;
      delete n1;
    } else {
      return GENOPER_OPFAIL;
    }
  } else {
    // change a node
    // the only nodes that are modifiable are MUT_CHAN_CODES
    // try to get a modifiable node
    // already picked a node, but repeat may be needed
    i=0;
    while (1) {
      if (strchr(MUT_CHAN_CODES, n1->name)) break; 
      // try a new one
      n1 = g->child->randomNode(); 
      i++;
      if (i>=20) return GENOPER_OPFAIL;
    }
    switch (n1->name) {
      case '<':
        // swap children
        n2 = n1->child; n1->child = n1->child2; n1->child2 = n2;
        break;
      case '[':
        linkNodeChangeRandom(n1);
        break;
      case '#':
        repeatNodeChangeRandom(n1);
        break;
    }
  }}
  
  return GENOPER_OK;
}

// make a random [ node
void TGeno_f4::linkNodeMakeRandom(f4node * nn)
{
  int i;
  float prob1;

  i = 0;
  // * G, 10% chance each
  prob1 = 1.0f / RAND_MAX * rand();
  prob1 -= 0.10f;
  if (prob1 < 0) i=1;
  else {
    prob1 -= 0.10f;
    if (prob1 < 0) i=2;
  }
  nn->i1 = i;
  nn->l1 = 0;
  if (0 == i) {
     // relative input link
     nn->l1 = (int)(4.0f * (1.0f /  RAND_MAX * rand() - 0.5f));
  }
  // weight
  nn->f1 = 10.0f * (1.0f / RAND_MAX * rand() - 0.5f);
}

// change a [ node
void TGeno_f4::linkNodeChangeRandom(f4node * nn)
{
  int i;
  float prob1, prob2;

  // 10% change type
  // 30% change link
  // 60% change weight
  prob1 = 1.0f / RAND_MAX * rand();
  prob1 -= 0.10f;
  if (prob1 < 0) {
    // change type
    i = 0;
    // * G, 10% chance each
    prob2 = 1.0f / RAND_MAX * rand();
    prob2 -= 0.10f;
    if (prob2 < 0) i=1;
    else {
      prob2 -= 0.10f;
      if (prob2 < 0) i=2;
    }
    nn->i1 = i;
  } else {
  prob1 -= 0.30f;
  if (prob1 < 0) {
    // change link
    if (0 == nn->i1) {
      // relative input link
      nn->l1 += (int)(2.0f * (1.0f /  RAND_MAX * rand() - 0.5f));
    }
  } else {
    // change weight
    nn->f1 += 1.0f * (1.0f / RAND_MAX * rand() - 0.5f);
  }}
}

// change a repeat # node
void TGeno_f4::repeatNodeChangeRandom(f4node * nn)
{
  int count;
  float prob1;

  // change count
  count = nn->i1;
  prob1 = 1.0f / RAND_MAX * rand();
  if (prob1 < 0.5f) count++;
               else count--;
  if (count<1) count=1;
  if (count>REP_MAXCOUNT) count=REP_MAXCOUNT;
  nn->i1 = count;
}


int TGeno_f4::MutateOneValid(f4node *& g, float &chg)
// mutate one, until a valid genotype is obtained
{
  // ! the genotype is g->child (not g) !
  int i, res;
  f4node * gcopy = NULL;
  // try this max 20 times:
  //   copy, mutate, then validate

  for (i=0; i<20; i++) {
    gcopy = g->duplicate();

    res = MutateOne(gcopy, chg);

    if (GENOPER_OK != res) {
      delete gcopy;
      res = GENOPER_OPFAIL;
      goto retm1v;
    }
    // try to validate it
    res = ValidateRec(gcopy, 10);
    if ((GENOPER_OK == res) ||
        (GENOPER_REPAIR == res)) {
      // ok, accept it
      // destroy the original one
      g->destroy();
      // make it the new one
      *g = *gcopy;
      gcopy->child=NULL;
      gcopy->child2=NULL;
      delete gcopy;
      res = GENOPER_OK;
      goto retm1v;
    }
    delete gcopy;
  }
  // attempts failed
  res = GENOPER_OPFAIL;
retm1v:
  return res;
}


int TGeno_f4::Mutate(char *& g, float &chg)
// check if original is valid, then
// make a number of mutations
{
  int res, n, i;

  // convert to tree
  f4node * root;
  root = new f4node();
  res = processf4rec(g, 0, root);
  if (res) {
    // could not convert, fail
    goto retm;
  }
  if (1 != root->childCount()) {
    res = GENOPER_OPFAIL;
    goto retm;
  }
  
  // check if original is valid
  res = ValidateRec( root, 20 ); 
  // might have been repaired!
  if (GENOPER_REPAIR==res) {
    res = GENOPER_OK;
  }
  if (GENOPER_OK != res) {
    goto retm;
  }

  // number of mutations is proportional to number of nodes (rough)
  n = (int)( chg * (float)(root->child->count()) );
  if (chg>0) if (n<1) n=1;
  for (i=0; i<n; i++) {
    res = MutateOneValid(root, chg);
    if (GENOPER_OK != res) { 
      res = GENOPER_OPFAIL;
      goto retm;
    }
  }
  // OK, convert back to string
  g[0]=0;
  root->child->sprintAdj(g);
retm:
  delete root;
  return res;
}


int TGeno_f4::CrossOverOne(f4node * g1, f4node * g2, float chg)
{
  // ! the genotypes are g1->child and g2->child (not g1 g2) !
  // single offspring in g1
  int smin, smax;
  float size;
  f4node * n1, * n2, * n1p, * n2p;

  // determine desired size
  size = (1-chg) * (float)g1->count();
  smin = (int)(size*0.9f-1);
  smax = (int)(size*1.1f+1);
  // get a random node with desired size
  n1 = g1->child->randomNodeWithSize(smin, smax);

  // determine desired size
  size = (1-chg) * (float)g2->count();
  smin = (int)(size*0.9f-1);
  smax = (int)(size*1.1f+1);
  // get a random node with desired size
  n2 = g2->child->randomNodeWithSize(smin, smax);

  // exchange the two nodes:
  n1p = n1->parent;
  n2p = n2->parent;
  n1p->removeChild(n1);
  n1p->addChild(n2);
  n2p->removeChild(n2);
  n2p->addChild(n1);
  n1->parent = n2p;
  n2->parent = n1p;

  return GENOPER_OK;
}

int TGeno_f4::CrossOver(char *&g1, char *&g2, float &chg1, float &chg2)
{
  int i, res;
  f4node * root1, * root2, * copy1, * copy2;
  copy1 = copy2 = NULL;

  // convert genotype strings into tree structures
  root1 = new f4node();
  res = processf4rec(g1, 0, root1);
  if ((res) || (1 != root1->childCount())) {
    delete root1;
    return GENOPER_OPFAIL;
  }
  root2 = new f4node();
  res = processf4rec(g2, 0, root2);
  if ((res) || (1 != root2->childCount())) {
    delete root1;
    delete root2;
    return GENOPER_OPFAIL;
  }

  // try to crossover for child1 10 times
  for (i=0; i<10; i++) {
    delete copy1;
    copy1 = root1->duplicate();
    res = CrossOverOne(copy1, root2, chg1);
    if (GENOPER_OK != res) goto crossfail1;
    // try to validate it
    res = ValidateRec(copy1, 10);
    if ((GENOPER_OK == res) ||
        (GENOPER_REPAIR == res)) goto child2;
  }
  // all attempts failed
crossfail1:
  delete copy1;
  res = GENOPER_OPFAIL;
  goto cross1;
child2:
  // try to crossover for child2 10 times
  for (i=0; i<10; i++) {
    delete copy2;
    copy2 = root2->duplicate();
    res = CrossOverOne(copy2, root1, chg2);
    if (GENOPER_OK != res) goto crossfail2;
    // try to validate it
    res = ValidateRec(copy2, 10);
    if ((GENOPER_OK == res) ||
        (GENOPER_REPAIR == res)) goto crossok;
  }
  // all attempts failed
crossfail2:
  delete copy2;
  delete copy1;
  res = GENOPER_OPFAIL;
  goto cross1;
crossok:
  // convert back to strings
  g1[0]=0;
  copy1->child->sprintAdj(g1);
  g2[0]=0;
  copy2->child->sprintAdj(g2);
  delete copy2;
  delete copy1;
  res = GENOPER_OK;

cross1:
  // release memory
  delete root2;
  delete root1;

  return res;
}


float TGeno_f4::Similarity(char* geno1, char* geno2)
{
  // not implemented
  // return a constant value
  return 0.5f;
}

unsigned long TGeno_f4::Style(char *g, int pos)
{
  char ch = g[pos];
  // style categories
  #define STYL4CAT_MODIFIC "LlRrCc,"
  #define STYL4CAT_NEUMOD "[]|@*G:"
  #define STYL4CAT_DIGIT "0123456789-."
  #define STYL4CAT_REST "XN<># "
  if (!strchr(STYL4CAT_MODIFIC STYL4CAT_NEUMOD STYL4CAT_DIGIT STYL4CAT_REST, ch))
    return GENSTYLE_CS(0,GENSTYLE_INVALID);
  unsigned long style=GENSTYLE_CS(0,GENSTYLE_STRIKEOUT); //default, should be changed below
  if (strchr("X ", ch))              style=GENSTYLE_CS(0,GENSTYLE_NONE);
  if (strchr("N", ch))               style=GENSTYLE_RGBS(0,200,0,GENSTYLE_NONE);  
  if (strchr("<", ch))               style=GENSTYLE_RGBS(0,0,200,GENSTYLE_BOLD);  
  if (strchr(">", ch))               style=GENSTYLE_RGBS(0,0,100,GENSTYLE_NONE);  
  if (strchr(STYL4CAT_DIGIT, ch))     style=GENSTYLE_RGBS(100,100,100,GENSTYLE_NONE);
  if (strchr(STYL4CAT_MODIFIC, ch))   style=GENSTYLE_RGBS(100,100,100,GENSTYLE_NONE);
  if (strchr(STYL4CAT_NEUMOD, ch))    style=GENSTYLE_RGBS(0,150,0,GENSTYLE_NONE);
  return style;
}



cell4::cell4(cells4 * nO, int nname, f4node * ngeno, f4node * ngcur,
    attrPart * ndad, int nangle, float nlen, float ncurv, float ntwist)
 : attrPart(nname, "cell", T_UNDIFF4, NULL, ndad)
{
  sti   = new stick(nname, ndad, nangle, nlen, ncurv, ntwist);
  neu   = new neuron(nname, ndad);
  type  =  T_UNDIFF4;
  org   = nO;
  genot = ngeno;
  gcur  = ngcur;
  active = 1;
  repet_node = NULL;
  repet_count = -1;
}

cell4::~cell4()
{
  delete neu;
  delete sti;
}


/* return codes:
    >1 error at pos
     0  halt development for a cycle
    -1  development finished OK  
*/
int cell4::onestep()
{
  int i, j, k, relfrom, t;
  float w;
  float le2, cu2, tw2;
  cell4 * tmp;
  neuron * tneu;
  if (gcur == NULL) {
    active = 0;
    return 0;  // stop
  }
  while ( gcur ) {
    //DB( printf("  %d (%d) executing '%c' %d\n", name, type, gcur->name, gcur->pos); )
    switch (gcur->name) {
    case '<':
      // cell division!
      //DB( printf("  div! %d\n", name); )

      // error: sticks cannot divide
      if (T_STICK4 == type) {
        // cannot fix
        org->setError(gcur->pos);
        return 1;  // stop
      }

      // undiff divides
      if (T_UNDIFF4 == type) {
        // commacount is set only when daughter turns into X
        // daughter cell
        // adjust new len
        le2 = sti->len;
        cu2 = sti->curved;
        tw2 = sti->twist;
        length_adj( &le2 );
        curved_adj( &cu2 );
        tmp = new cell4(org, org->nc, genot, gcur->child2, 
         this, sti->commacount, le2, cu2, tw2);
        tmp->repet_node  = repet_node;
        tmp->repet_count = repet_count;
        repet_node  = NULL;
        repet_count = -1;
        org->addCell( tmp );
      }
      // a neuron divides: create a new, duplicate links
      if (T_NEURON4 == type) {
        // daughter cell
        tmp = new cell4(org, org->nc, genot, gcur->child2, 
        // has the same dadlink
        this->dadlink, sti->commacount, sti->len, sti->curved, sti->twist);
        tmp->repet_node  = repet_node;
        tmp->repet_count = repet_count;
        repet_node  = NULL;
        repet_count = -1;
        // it is a neuron from start
        tmp->type = T_NEURON4;
        // duplicate links
        nlink * ll;
        for (i=0; i<neu->nolink; i++) {
          ll = neu->links[i];
          tmp->neu->addlink(ll->from, ll->w, ll->t);
        }
        org->addCell( tmp );
      }
      // adjustments for this cell
      gcur = gcur->child;
      // halt development
      return 0;

    case '>':
      // finish
      // see if there is a repet count
      if ((NULL != repet_node) &&
         (repet_count > 0)) {
        repet_count--;
        if (repet_count > 0) {
          // return to repeat
          gcur = repet_node->child;
        } else {
          // continue
          gcur = repet_node->child2;
          repet_node = NULL; repet_count = -1;
        }
        break;
      } else {
        // error: still undiff
        if (T_UNDIFF4 == type) {
          // fix it: insert an 'X'
          f4node * insertnode = new f4node('X', NULL, gcur->pos);          
          if (org->setRepairInsert(gcur->pos, gcur, insertnode))
            // not in repair mode, release
            delete insertnode;
          return 1;
        }
        // eat up rest
        gcur = NULL;
        repet_node = NULL; repet_count = -1;
        active = 0;  // stop
        return 0;
      }

    case '#':
      // repetition marker
      if (NULL != repet_node) {
        // there is already an active repeat counter!
      }
      repet_node = gcur;
      repet_count = gcur->i1;
      gcur = gcur->child;
      break;

    case ',':
      sti->commacount++;
      gcur = gcur->child;
      break;

    case 'l':  case 'L':
    case 'c':  case 'C':
    case 'q':  case 'Q':
    case 'r':  case 'R':
      // error: if neuron
      if (T_NEURON4 == type) {
        // fix: delete it
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      switch (gcur->name) {
      case 'l':
        length_dec( &(sti->len) );      break;
      case 'L':
        length_inc( &(sti->len) );      break;
      case 'c':
        curved_dec( &(sti->curved) );   break;
      case 'C':
        curved_inc( &(sti->curved) );   break;
      case 'q':
        break;
      case 'Q':
        break;
      case 'r':
        rolling_dec( &(sti->rolling) ); break;
      case 'R':
        rolling_inc( &(sti->rolling) ); break;
      }
      gcur = gcur->child;
      break;

    case 'X':
      // turn undiff. cell into a stick
      // error: already differentiated
      if (T_UNDIFF4 != type) {
        // fix: delete this node
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      type = T_STICK4;
      // fix dad commacount and own anglepos
      if (NULL != dadlink) {
        ((cell4*)dadlink)->sti->commacount++; 
        sti->anglepos = ((cell4*)dadlink)->sti->commacount;
      }
      // change of type halts developments, see comment at 'N'
      gcur = gcur->child;
      return 0;

    case 'N':
      // turn undiff. cell into a neuron
      // error: already differentiated
      if (T_UNDIFF4 != type) {
        // fix: delete this node
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      // error: if no previous
      if (NULL == dadlink) {
        // fix: delete it
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      type = T_NEURON4;
      // change of type also halts development, to give other
      // cells a chance for adjustment.  Namely, it is important
      // to wait for other cells to turn N before adding links
      gcur = gcur->child;
      return 0;

    case '@':
    case '|':
      // neuron rotating / bending
      j = 1;
      if ('@' == gcur->name) j = 1; // rot
      if ('|' == gcur->name) j = 2; // bend
      // error: not a neuron (undiff)
      if (T_UNDIFF4 == type) {
        // fix: delete it
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      // error: not a neuron (stick)
      if (T_NEURON4 != type) {
        // fix: delete it
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      // error: already has control
      if (neu->ctrl != 0) {
        // fix: delete it
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      // make neuron ctrl = 1 or 2
      neu->ctrl = j;
      gcur = gcur->child;
      break;
       
    case '[':
      // link to neuron
      // error: not a neuron
      if (T_NEURON4 != type) {
        // fix: delete it
        org->setRepairRemove(gcur->pos, gcur);
        return 1;  // stop
      }
      // input ('*', 'G', or %d)
      t       = gcur->i1;
      relfrom = gcur->l1;
      w       = gcur->f1;
      if (t>0) {
        // * or G
        tneu = NULL;
      } else {
        // input from other neuron
        // find neuron at relative i
        // find own index
        j = 0; k = 0;
        for(i=0; i<org->nc; i++) {
          if (org->C[i]->type == T_NEURON4) k++;
          if (org->C[i] == this) {j=k-1; break;}
        }
        // find index of incoming
        j = j + relfrom;
        if (j<0) goto wait_link;
        if (j>=org->nc) goto wait_link;
        // find that neuron
        k = 0;
        for(i=0; i<org->nc; i++) {
          if (org->C[i]->type == T_NEURON4) k++;
          if (j == (k-1)) break;
        }
        if (i>=org->nc) goto wait_link;
        tneu = (neuron*) org->C[i];
      }
      // add link
      // error: could not add link
      if (neu->addlink(tneu, w, t)) {
        // cannot fix
        org->setError(gcur->pos);
        return 1;  // stop
      }
      gcur = gcur->child;
      break;
    wait_link:
      // wait for other neurons to develop
      // if there are others still active
      active = 0;
      j = 0;
      for(i=0; i<org->nc; i++) {
        if (org->C[i]->active) j++;
      }
      if (j>0)   return 0;
      else {
        // no more actives
        org->setError(gcur->pos+1);
        return 1;
      }

    case ' ':
      // space has no effect, should not occur
      // fix: delete it
      org->setRepairRemove(gcur->pos, gcur);
      gcur = gcur->child;
      break;

    default:
      // error: unknown code
      char buf[40];
      sprintf(buf, "unknown code '%c'", gcur->name);
      FramMessage("cell4", "onestep", buf, 2);
      // fix: delete it
      org->setRepairRemove(gcur->pos, gcur);
      return 1; // stop
    }
  }
  active = 0;  // done
  return 0;
}


cells4::cells4(f4node * fullgenome, int nrepair)
{
  // create ancestor cell
  C[0] = new cell4(this, 0, fullgenome, fullgenome, NULL, 0, 1.0f, 0, 0);
  nc   = 1;
  repair = nrepair;
  error  = 0;
  errorpos = -1;
  repair_remove = NULL;
  repair_parent = NULL;
  repair_insert = NULL;
}

cells4::~cells4()
{
  // release cells
  int i;
  if (nc) {
    for (i=nc-1; i>=0; i--) 
      delete C[i];
    nc = 0;
  }
}


int cells4::onestep()
{
  int i, ret, oldnc, ret2;
  oldnc = nc;
  ret=0;
  for (i=0; i<oldnc; i++) {
    ret2 = C[i]->onestep();
    if (ret2>0) {
      // error
      C[i]->active = 0;  // stop
      return 0;
    }
    // if still active
    if (C[i]->active)
      ret=1;
  }
  return ret;
}


int cells4::simulate()
{
  int i;
  error = GENOPER_OK;

  for (i=0; i<nc; i++)  C[i]->active = 1;

  // execute onestep() in a cycle
  while (onestep()) ;

  if (GENOPER_OK != error) return error;

  // fix neuron attachements
  for(i=0; i<nc; i++)
    if (C[i]->type == T_NEURON4) {
      while (T_NEURON4 == C[i]->dadlink->type) {
        C[i]->dadlink = C[i]->dadlink->dadlink;
      }
  }
  //DB( printf("Cell simulation done, %d cells. \n", nc); )

  return error;
}


void cells4::addCell(cell4 * newcell)
{
  if (nc >= MAX4CELLS-1) {
    delete newcell;
    return;
  }
  C[nc] = newcell;
  nc++;
}


void cells4::setError(int nerrpos) 
{ 
  error = GENOPER_OPFAIL; 
  errorpos = nerrpos;
}

void cells4::setRepairRemove(int nerrpos, f4node * rem)
{
  if (!repair) {
    // not in repair mode, treat as repairable error
    error = GENOPER_REPAIR;
    errorpos = nerrpos; 
  } else {
    error = GENOPER_REPAIR; 
    errorpos = nerrpos; 
    repair_remove = rem;
  }
}

int cells4::setRepairInsert(int nerrpos, f4node * parent, f4node * insert)
{
  if (!repair) {
    // not in repair mode, treat as repairable error
    error = GENOPER_REPAIR;
    errorpos = nerrpos; 
    return -1;
  } else {
    error = GENOPER_REPAIR; 
    errorpos = nerrpos; 
    repair_parent = parent;
    repair_insert = insert;
    return 0;
  }
}

void cells4::repairGeno(f4node * geno, int whichchild)
{
  // assemble repaired geno, if the case
  if (!repair) return;
  if ((NULL==repair_remove) && (NULL==repair_insert)) return;
  // traverse genotype tree, remove / insert node
  f4node * g2;
  if (1==whichchild) g2 = geno->child;
    else             g2 = geno->child2;
  if (NULL == g2)
    return;
  if (g2 == repair_remove) {
    f4node * oldgeno;
    geno->removeChild(g2);
    if (g2->child) {
      // add g2->child as child to geno
      if (1==whichchild) geno->child  = g2->child;
        else             geno->child2 = g2->child;
      g2->child->parent = geno;
    }
    oldgeno = g2;
    oldgeno->child = NULL;
    delete oldgeno;
    if (NULL == geno->child) return;
    // check this new 
    repairGeno(geno, whichchild);
    return;
  }
  if (g2 == repair_parent) {
    geno->removeChild(g2);
    geno->addChild(repair_insert);
    repair_insert->parent = geno;
    repair_insert->child  = g2;
    repair_insert->child2 = NULL;
    g2->parent = repair_insert;
  }
  // recurse
  if (g2->child)  repairGeno(g2, 1);
  if (g2->child2) repairGeno(g2, 2);
}


// scan genotype string and build tree
// return >1 for error (errorpos)
int processf4rec(char * genot, unsigned pos0, f4node * parent)
{
  int i, j, relfrom, t, res;
  float w;
  unsigned gpos, oldpos;
  f4node * node1, * par;

  gpos = pos0;
  par = parent;
  if (gpos >= strlen(genot) ) return 1;
  while (gpos<strlen(genot)) {
    //DB( printf(" processing '%c' %d %s\n", genot[gpos], gpos, genot); )
    switch (genot[gpos]) {
    case '<':
      // cell division!
      //DB( printf("  div! %d\n", name); )

      // find out genotype start for child
      j = scanrec(genot+gpos+1, '>');

      node1 = new f4node('<', par, gpos);
      par = node1;
      res = processf4rec(genot, gpos+1,   par);
      if (res) return res;
      if (gpos+j+2 < strlen(genot)) {
        res = processf4rec(genot, gpos+j+2, par);
        if (res) return res;
      } else {  // ran out
        node1 = new f4node('>', par, strlen(genot)-1 );
        par = node1;
      }
      // adjustments
      gpos++;
      return 0;  // OK

    case '>':
      node1 = new f4node('>', par, gpos );
      par = node1;
      gpos = strlen(genot);
      return 0;  // OK

    case '#':
      // repetition marker, 1 by default
      if (sscanf(genot+gpos, "#%d", &i) != 1) i=1;
      // find out genotype start for continuation
      j = scanrec(genot+gpos+1, '>');
      // skip number
      oldpos = gpos;
      gpos++;
      while ((genot[gpos]>='0') && (genot[gpos]<='9')) gpos++;
      node1 = new f4node('#', par, oldpos );
      node1->i1 = i;
      par = node1;
      res = processf4rec(genot, gpos,   node1);
      if (res) return res;
      if (oldpos+j+2 < strlen(genot) ) {
        res = processf4rec(genot, oldpos+j+2, node1);
        if (res) return res;
      } else {  // ran out
        node1 = new f4node('>', par, strlen(genot)-1 );
      }
      return 0;  // OK

    // 'simple' nodes:
    case ',':
    case 'l':  case 'L':
    case 'c':  case 'C':
    case 'q':  case 'Q':
    case 'r':  case 'R':
    case 'X':  case 'N':
    case '@':  case '|':
    case 'w':  case 'W':
    case 'f':  case 'F':
    case 'a':  case 'A':
    case 's':  case 'S':
    case 'm':  case 'M':
    case 'i':  case 'I':
    case 'e':  case 'E':
      node1 = new f4node(genot[gpos], par, gpos );
      par = node1;
      gpos++;
      break;

    case '[':
      // link to neuron
      // input ('*', 'G', or %d)
      t = -1;
      if (sscanf(genot+gpos, "[*:%f]", &w) == 1) t=1;
      if (sscanf(genot+gpos, "[G:%f]", &w) == 1) t=2;
      if (sscanf(genot+gpos, "[%ld:%f]", &relfrom, &w) == 2) t=0;
      // error: no correct format
      if (t<0) return gpos+1+1;
      node1 = new f4node('[', par, gpos );
      node1->i1 = t;
      node1->l1 = relfrom;
      node1->f1 = w;
      par = node1;
      j = scanrec(genot+gpos+1, ']');
      gpos += j+2;
      break;

    case ' ':  
    case '\n':  
    case '\t':  
      // whitespace: ignore
      //node1 = new f4node(' ', par, gpos );
      //par = node1;
      gpos++;
      break;

    default:
      //DB( printf("unknown character '%c' ! \n", genot[gpos]); )
      //add it, build will give the error or repair
      node1 = new f4node(genot[gpos], par, gpos );
      par = node1;
      gpos++;
      break;
    }
  }
  // should end with a '>'
  if (par)
    if ('>' != par->name) {
      node1 = new f4node('>', par, strlen(genot)-1 );
      par = node1;
  }
  return 0;  // OK
}


f4node * processf4(char * geno)
{
  f4node * root;
  int res;
  root = new f4node();
  res = processf4rec(geno, 0, root);
  if (res) return NULL;
  //DB( printf("test f4  "); )
  DB(
    if (root->child) {
      char * buf = (char*) malloc( 300 );
      DB( printf("(%d) ", root->child->count() ); )
      buf[0]=0;
      root->child->sprintAdj(buf);
      DB( printf("%s\n", buf); )
      free(buf);
    }
  )
  return root->child;
}


// to organize a f4 genotype in a tree structure

f4node::f4node()
{
  name   = '?';
  parent = NULL;
  child  = NULL;
  child2 = NULL;
  pos    = -1;
}

f4node::f4node(char nname, f4node * nparent, int npos)
{
  name   = nname;
  parent = nparent;
  child  = NULL;
  child2 = NULL;
  pos    = npos;
  if (parent) parent->addChild(this);
}

f4node::~f4node()
{
  // (destroy() copied here for efficiency)
  // children are destroyed (recursively) through the distructor
  if (NULL != child2)  delete child2;
  if (NULL != child)   delete child;
}

int f4node::addChild(f4node * nchi)
{
  if (NULL==child) {
    child = nchi;
    return 0;
  }
  if (NULL==child2) {
    child2 = nchi;
    return 0;
  }
  return -1;
}

int f4node::removeChild(f4node * nchi)
{
  if (nchi==child2) {
    child2 = NULL;
    return 0;
  }
  if (nchi==child) {
    child = NULL;
    return 0;
  }
  return -1;
}

int f4node::childCount(void)
{
  if (NULL!=child) {
    if (NULL!=child2) return 2;
                 else return 1;
  } else {
    if (NULL!=child2) return 1;
                 else return 0;
  }
}

int f4node::count(void)
{
  int c=1;
  if (NULL!=child)  c+=child->count();
  if (NULL!=child2) c+=child2->count();
  return c;
}

f4node * f4node::ordNode(int n)
{
  int n1;
  if (0 == n) return this;
  n--;
  if (NULL != child) {
    n1 = child->count();
    if (n<n1) return child->ordNode(n);
    n -= n1;
  }
  if (NULL != child2) {
    n1 = child2->count();
    if (n<n1) return child2->ordNode(n);
    n -= n1;
  }
  return NULL;
}

f4node * f4node::randomNode(void)
{
  int n, i;
  n = count();
  // pick a random node, between 0 and n-1
  i = (int)( ((float)n-0.0001) / RAND_MAX * rand());
  return ordNode(i);
}

f4node * f4node::randomNodeWithSize(int min, int max)
{
  // try random nodes, and accept if size in range
  // limit to maxlim tries 
  int i, n, maxlim;
  f4node * nod;
  maxlim = count();
  for (i=0; i<maxlim; i++) {
    nod = randomNode();
    n = nod->count();
    if ((n>=min) && (n<=max)) return nod;
  }
  // failed, doesn't matter
  return nod;
}

void f4node::sprint(sstring & out)
{
  char buf2[20];
  // special case: repetition code
  if ('#' == name) {
    out += "#";
    if (i1 != 1) {
      sprintf(buf2, "%d", i1);
      out += buf2;
    }
  } else {
  // special case: neuron link
  if ('[' == name) {
    out += "[";
    if (i1>0) {
      // sensor input
      if (1==i1) out += "*";
      if (2==i1) out += "G";
    } else {
      sprintf(buf2, "%ld", l1);
      out += buf2;
    }
    sprintf(buf2, ":%g]", f1);
    out += buf2;
  } else {
    buf2[0] = name;
    buf2[1] = 0;
    out += buf2;
  }}
  if (NULL != child)     child->sprint(out);
  // if two children, make sure last char is a '>'
  if (2 == childCount())
    if (0 == out[0]) out += ">"; else
      if ('>' != out[strlen((char*)out)-1]) out += ">";
  if (NULL != child2)    child2->sprint(out);
  // make sure last char is a '>'
  if (0 == out[0]) out += ">"; else
    if ('>' != out[strlen((char*)out)-1]) out += ">";
}

void f4node::sprintAdj(char *& buf)
{
  unsigned int len;
  // build in a sstring, with initial size
  sstring out(strlen(buf)+200);
  out="";

  sprint(out);

  // very last '>' can be omitted
  len = strlen((char*)out);
  if (len>1)
    if ('>' == out[len-1]) out[len-1]=0;
  // copy back to string
  // if new is longer, reallocate buf
  if (len+1 > strlen(buf)) {
    buf = (char*) realloc(buf, len+1 );
  }
  strcpy(buf, (char*) out);
}

f4node * f4node::duplicate(void)
{
  f4node * copy;
  copy = new f4node(*this);
  copy->parent = NULL;  // set later
  copy->child  = NULL;
  copy->child2 = NULL;
  if (NULL != child ) {
    copy->child  = child ->duplicate();
    copy->child ->parent = copy;
  }
  if (NULL != child2 ) {
    copy->child2 = child2->duplicate();
    copy->child2->parent = copy;
  }
  return copy;
}


void f4node::destroy(void)
{
  // children are destroyed (recursively) through the destructor
  if (NULL != child2)  delete child2;
  if (NULL != child)   delete child;
}
