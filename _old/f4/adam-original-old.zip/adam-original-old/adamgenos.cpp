/*
 * adamgenos.cpp - genotype conversion utilities.
 * 2000.6.30.  1999.11.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "adamgenos.h"
#include "geno_f4.h"
#ifndef MAIN_FRAMSTICKS
  #include "geno_f5.h"
#endif // MAIN_FRAMSTICKS


#ifndef MAIN_FRAMSTICKS
int geno_conv(char *in, int outformat, sstring &out) 
{
  int inputformat;

  // build from 0, 1 or 2
  inputformat = genkonwmanager::wersjagenow(in) - '0';

  DB( fprintf(stderr, "converting f%d->f%d ...\n", inputformat, outformat); )

  if (0==inputformat) {
    if (0==outformat) {
      // 0->0  no conversion
      out = in;
      return 1;
    } else
      return 0;
  }

  if (1==inputformat)
    return Convert_f1( genkonwmanager::ominkomentarz(in), outformat, out);
  if (4==inputformat)
    return Convert_f4( genkonwmanager::ominkomentarz(in), outformat, out);
  if (5==inputformat)
    return Convert_f5( genkonwmanager::ominkomentarz(in), outformat, out);
  return 0; // sorry
}
#endif // MAIN_FRAMSTICKS


int Convert_f1(char *in, int outformat, sstring &out) 
{
  int res;
  // converts to '0' or '1'
  if ((0!=outformat) && (1!=outformat)) return 0;

  // build organism
  Organism Org;
  res = Org.buildfrom1( in );
  if (GENOPER_OK != res) return 0;  // oops
  
  // print out into 0 (or 1)
  //DB( Org.print(); )
  out = 300;
  out = "";
  if (0==outformat) Org.to0(out);
  if (1==outformat) Org.to1(out);
  return 1;	// ok
}

int Convert_f1_to_f0(char *in, sstring &out)
{ return Convert_f1(in, 0, out); }


// length increase/decrease for "l" and "L"

void length_dec(float * lenv) {
  *lenv += (0.33f - *lenv) * 0.3f;
}
void length_inc(float * lenv) {
  *lenv += (3.0f - *lenv) * 0.3f;
  if (*lenv > LEN_MAX) *lenv = LEN_MAX;
}
void length_adj(float * lenv) {
  *lenv = (1.0f + *lenv) * 0.5f;
}

void curved_dec(float * v) {
  *v = (*v) - 0.33f;
}
void curved_inc(float * v) {
  *v = 0.75f * (*v) + 0.33f;
}
void curved_adj(float * v) {
  *v = 0.66f * (*v);
}

void rolling_dec(float * v) {
  *v -= 0.7853981f;  // 45 degrees
}
void rolling_inc(float * v) {
  *v += 0.7853981f;
}


absAttribute::absAttribute(char * nname)
{
  name = new char[ strlen(nname)+1 ];
  strcpy(name, nname);
}

absAttribute::~absAttribute()
{
  delete[] name;
}

floatAttribute::floatAttribute(char * nname, float ndefval, float * nval)
  : absAttribute(nname)
{
  defval = ndefval;
  val    = nval;
  *val   = defval;
}

void floatAttribute::sprint(char * buf)
{
  char buf2[20];
  sprintf(buf2, "%g", *val);
  strcat(buf, buf2);
}

longAttribute::longAttribute(char * nname, long ndefval, long * nval)
  : absAttribute(nname)
{
  defval = ndefval;
  val    = nval;
  *val   = defval;
}

void longAttribute::sprint(char * buf)
{
  char buf2[20];
  sprintf(buf2, "%ld", *val);
  strcat(buf, buf2);
}


attribObject::attribObject(char * nname)
{ 
  f0name = new char[ strlen(nname)+1 ];
  strcpy(f0name, nname);
  nattr = 0;
}

void attribObject::operator=(const attribObject & o)
{
  strcpy(f0name, o.f0name);
  removeAttrs();
  defAttrs();
}

attribObject::~attribObject()
{
  removeAttrs();
  delete[] f0name;
}

void attribObject::removeAttrs()
{
  if (nattr) {
    int i;
    for (i=nattr-1; i>=0; i--) {
      delete A[i];
    }
    nattr = 0;
  }
}

void attribObject::addFloatAttr(char * nname, float ndefval, float * nval)
{
  if (nattr >= MAXATTR-1) return;
  A[nattr] = new floatAttribute(nname, ndefval, nval);
  nattr++;
}

void attribObject::addLongAttr(char * nname, long ndefval, long * nval)
{
  if (nattr >= MAXATTR-1) return;
  A[nattr] = new longAttribute(nname, ndefval, nval);
  nattr++;
}

void attribObject::reset(void)
{
  int i;
  for (i=0; i<nattr; i++)  A[i]->reset();
}

void attribObject::sprint(char * buf, int len)
{
  int i, inorder, isfirst;
  char buf2[100];

  updateB4print();
  buf[0]=0;
  sprintf(buf2, "%s:", f0name);
  strcat(buf, buf2);
  inorder=1; isfirst=1;
  for (i=0; i<nattr; i++) {
    if (A[i]->different()) {
      if (!isfirst) strcat(buf, ", ");
        else isfirst=0;
      if (!inorder) {
        sprintf(buf2, "%s=", A[i]->name);
        strcat(buf, buf2);
        inorder=1;
      }
      A[i]->sprint(buf);
      inorder=1;
    } else inorder=0;
  }
  strcat(buf, "\n");
}


attrPart::attrPart(int nname, char * f0name, int ntype, 
                   Organism * norg, attrPart * ndad)
  : attribObject(f0name)
{
  name    = nname;
  type    = ntype;
  org     = norg;
  dadlink = ndad;
}

endpoint::endpoint(void) 
  : attribObject("p")
{ 
  sumpos = Vector(0,0,0);
  count = 0;
  defAttrs(); 
}

void endpoint::defAttrs(void)
{
  addFloatAttr("x",   0.0f,  &x);
  addFloatAttr("y",   0.0f,  &y);
  addFloatAttr("z",   0.0f,  &z);
  addFloatAttr("m",   1.0f,  &m);
  addFloatAttr("vol", 0.0f,  &vol);
  addFloatAttr("fr",  0.4f,  &fr);
  addFloatAttr("ing", 0.25f, &ing);
}


stick::stick(void)
  : attrPart(-1, "j", T_STICK0, NULL, NULL)
{
  defAttrs();
}

stick::stick(int nname, attrPart * ndad, int nangle, 
  float nlen, float ncurv, float ntwist)
  : attrPart(nname, "j", T_STICK0, org, ndad)
{
  anglepos = nangle;
  commacount = 0;
  childcount = 0;
  len     = nlen;
  curved  = ncurv;
  twist   = ntwist;
  rolling = 0;
  defAttrs();
  // adjust firstend and OM if there is a stick dad
  if (ndad != NULL) 
    // make sure it is a stick (and not a stick cell4!)
    if (T_STICK0 == ndad->type) {
//      if ('j' == ndad->f0name[0]) {
        stick * dadstick = (stick*) ndad;
        firstend = dadstick->lastend;
        OM = dadstick->OM;
        dadstick->childcount++;
    }
  // adjust lastend
  lastend = firstend + OM * (Vector(1,0,0) * len);
  mz = 1;
}

stick::stick(int nname, stick * ndad, int nangle)
  : attrPart(nname, "j", T_STICK0, org, ndad)
{
  anglepos = nangle;
  commacount = 0;
  childcount = 0;
  len = ndad->len;
  length_adj( &len );
  curved = ndad->curved;
  defAttrs();
  // adjust firstend and OM if there is a stick dad
  if (ndad != NULL) {
      firstend = ndad->lastend;
      OM = ndad->OM;
      ndad->childcount++;
  }
  // adjust lastend
  lastend = firstend + OM * (Vector(1,0,0) * len);
  mz = 1;
}

void stick::defAttrs(void)
{
  addLongAttr ("p1", -1.0f,  &p1);
  addLongAttr ("p2", -1.0f,  &p2);
  addFloatAttr("m" ,  0.25f, &m);
  addFloatAttr("as",  0.25f, &as);
  addFloatAttr("st",  0.25f, &st);
  addFloatAttr("mz",  1.0f,  &mz);
}

void stick::updateB4print(void)
{
  if (dadlink != NULL) {
    p1 = dadlink->name + 1;
    p2 = name + 1;
  }
}

DB(
void stick::print()
{
  printf("X [%d] ", name);
  if (NULL == dadlink) printf("no dad   ");
    else printf("dad [%d] %d ", dadlink->name, anglepos);
  printf("\t,c=%d l=%.2f c=%.2f r=%.2f \n", 
    commacount, len, curved, rolling);
}
)


neuron::neuron(void)
 : attrPart(-1, "neu", T_NEURON0, NULL, NULL)
{
  defAttrs();
}

neuron::neuron(int nname, attrPart * ndad)
 : attrPart(nname, "neu", T_NEURON0, org, ndad)
{
  defAttrs();
  nolink = 0;
}

neuron::~neuron()
{
  // remove links
  if (nolink) {
    int i;
    for (i=nolink-1; i>=0; i--)
      delete links[i];
    nolink=0;
  }
}

void neuron::defAttrs(void)
{
  addLongAttr ("est",         -1l,  &est);   // to force
  addLongAttr ("ctrl",         0l,  &ctrl);
  addFloatAttr("in",         0.8f,  &in);
  addFloatAttr("fo",        0.04f,  &fo);
  addLongAttr ("si",           2l,  &si);
}

void neuron::updateB4print(void)
{
  if (NULL != dadlink) est = dadlink->name;
}

int neuron::addlink(neuron * nfrom, float nw, int nt)
{
  if (nolink >= MAXINPUTS-1) return 1; // full!
  links[nolink] = new nlink(nfrom, this);
  links[nolink]->t    = nt;
  links[nolink]->w    = nw;
  nolink++;
  return 0;
}

DB(
void neuron::print()
{
  printf("N [%d] ", name);
  if (NULL != dadlink)  printf("on %d  ", dadlink->name);
  printf(" in: %g ", in);
  printf(" %d inputs ", nolink);
  printf("\n");
}
)


nlink::nlink(neuron * nfrom, neuron * nto) 
  : attribObject("inp")
{ 
  from = nfrom;
  to   = nto;
  defAttrs();
}

void nlink::defAttrs(void)
{
  addLongAttr ("n",      -1l, &n);    // to force
  addLongAttr ("t",       1l, &t);
  addFloatAttr("w",     1.0f, &w);
  addLongAttr ("conn",-5000l, &conn); // to force
}
  
void nlink::updateB4print(void)
{
  if (NULL == to) n=0;
  else n = to->name;
  if (NULL == from) conn=0;
  else conn = from->name - to->name;
}


Organism::Organism()
{ 
  error = GENOPER_OK;
  errorpos = -1;
  ns = 0;
  tmp = NULL;
  empty();
}

Organism::~Organism()
{
  empty();
  delete tmp;
}

void Organism::empty()
{
  if (ns) {
    int i;
    for (i=ns-1; i>=0; i--)
      delete S[i];
    ns = 0;
  }
}

void Organism::add(attrPart * s)
{
  //DB( printf("add %d  ", ns); s->print(); )
  if (ns >= MAXST-1) { 
    delete s;
    seterror();
    return;
  }
  S[ns] = s; 
  ns++;
}


int Organism::buildfrom1(char * s)
{
  int ret;

  empty();
  error = GENOPER_OK;
  errorpos = -1;
  b1_Xcount=0;
  delete tmp;
  tmp = new stick(-1, NULL, 0, 1.0f, 0, 0);
  ret = parse1rec(s, NULL, 0, 0, 0);
  adjust();

  return error;
}


int Organism::parse1rec
    (char * s, stick * dadlink, int anglepos, char stop1, char stop2)
{
  unsigned i, j, k;
  int commacount;
  stick * newstick;
  stick tmpsave(*tmp);
  //DB( printf("--parsing %s \n", s); )

  for (i=0; i<strlen(s); i++)  {
    if (s[i] == stop1) return i;
    if (s[i] == stop2) return i;

    switch(s[i]) {
    case 'X':
      newstick = new stick(b1_Xcount, dadlink, anglepos+1);
      add(newstick);
      dadlink = newstick;
      b1_Xcount++;
      break;
   
    case '(':
      // branch. scan for matching ), count commas
      j = scanrec(s+i+1, ')');
      commacount=0;
      tmpsave = *tmp;
      for (k=i+1; k<i+j+1; k++) {
        *tmp = tmpsave;
        if (s[k] == ',') commacount++;
        else {
          k += parse1rec(s+k, newstick, commacount, ',', ')') -1; 
        }
      }
      // update commacount
      newstick->commacount = commacount+1;
      i=i+j+1;
      break;

    case 'l':		// decrease length
      length_dec( &(tmp->len) );
      break;
    case 'L':		// increase length
      length_inc( &(tmp->len) ); 
      break;
    }
  }
  return i;
}


int Organism::buildfrom4(char * s)
{
  // transform string genotype to node representation
  f4node * root;
  int res;

  error = GENOPER_OK;
  errorpos = -1;
  // transform geno from string to nodes
  root = new f4node();
  res = processf4rec(s, (unsigned)0, root);
  if ((res<0) || (1 != root->childCount())) {
    error = GENOPER_OPFAIL;
    errorpos = -1;
    return error;
  }

  error = buildfrom4(root, 0);
  // release memory
  delete root;

  return error;
}


int Organism::buildfrom4(f4node * g, int repair)
{
  // ! genotype is in g->child (not g) !
  // do these steps:
  // * simulate cells
  // * do adjustments
  int i, j;
  cell4 * c1;

  error = GENOPER_OK;
  errorpos = -1;
  // build cells, and simulate
  cells4 * C = new cells4(g->child, repair);
  C->simulate();

  if (GENOPER_OK != C->geterror()) {
    error = C->geterror();
    errorpos = C->geterrorpos();

    if (GENOPER_REPAIR == error) {
      if (repair) {
        C->repairGeno(g, 1);
      }
    }
    delete C;
    return error;
  }

  // there should be no undiff. cells
  // make undifferentiated cells sticks 
  for (i=0; i< C->nc ; i++)
    if (C->C[i]->type == T_UNDIFF4) {
      C->C[i]->type = T_STICK4;
      //seterror(); 
      delete C;
      return error;
  }

  empty();
  // fix dadlink pointers
  for (i=0; i< C->nc ; i++)
    if (NULL != C->C[i]->dadlink) {
      c1 = (cell4*) C->C[i]->dadlink;
      if (T_STICK4 == c1->type)  C->C[i]->dadlink = c1->sti;
      if (T_NEURON4 == c1->type)  C->C[i]->dadlink = c1->neu;
  }
  // fix neuron pointers
  for (i=0; i< C->nc ; i++)
    if (T_NEURON4 == C->C[i]->type) {
      for(j=0; j<C->C[i]->neu->nolink; j++) {
        c1 = (cell4*) (C->C[i]->neu->links[j]->from);
        if (NULL != c1) {
          if (T_STICK4 == c1->type) { 
            seterror(); 
            delete C;
            return error; 
          }
          C->C[i]->neu->links[j]->from = c1->neu;
        }
    }
  }

  for (i=0; i< C->nc ; i++) {
    C->C[i]->sti->dadlink = C->C[i]->neu->dadlink = (attrPart*) C->C[i]->dadlink;
  }

  // copy sticks
  for (i=0; i< C->nc ; i++)
    if (C->C[i]->type == T_STICK4) {
      add( C->C[i]->sti ); 
      C->C[i]->sti = NULL; // do not release it afterwards
  }

  // copy neurons
  for (i=0; i< C->nc ; i++)
    if (C->C[i]->type == T_NEURON4) {
      add( C->C[i]->neu ); 
      C->C[i]->neu = NULL; // do not release it afterwards
  }
  
  adjust();

  delete C;
  return error;
}


#ifndef MAIN_FRAMSTICKS
int Organism::buildfrom5(char * s)
{
  error = GENOPER_OK;
  errorpos = -1;
  Organism5 * Org = new Organism5(s);
  Org->simulate();

  // there should be no undiff. cells
  empty();
  // fix pointers
  // copy sticks

  adjust();
  delete Org;

  return error;
}
#endif


DB(
void Organism::print()
{
  int i;
  for(i=0; i<ns; i++) S[i]->print();
}
)


void Organism::to0(sstring &out)
{
  int i, j, k, m, nsti, nepo;
  char buf[200];
  endpoint p1;
  stick *  thisti;
  neuron * thneu;

  //out += "/*0*/\n";	// no version

  // count sticks and endpoints
  nsti = 0;
  nepo = 1;
  for(i=0; i<ns; i++) {
    if (T_STICK0 == S[i]->type) {
      S[i]->name = nsti;
      nsti++;  nepo++;
    }
  }

  // print first endpoint
  p1.reset();
  // coordinates are default (0,0,0)
  //matrix33 tmpM;  
  //tmpM.printox(out);
  p1.sprint(buf, 200);
  out += buf;

  // print rest of endpoints
  for(j=1; j<nepo; j++) { 
    for(i=0; i<ns; i++) 
      if (S[i]->type == T_STICK0)
        if (S[i]->name == j-1) {
          thisti = (stick*) S[i];
          p1.reset();
          p1.x=thisti->lastend.x;
          p1.y=thisti->lastend.y;
          p1.z=thisti->lastend.z;
          //thisti->OM.printox(out);
          // count sticks connected
          m = 1;
          for(k=0; k<ns; k++)
            if (S[k]->type == T_STICK0)
              if (S[k]->dadlink == S[i])
                m++;
          p1.m = m;
          p1.sprint(buf, 200);
          out += buf;
        }
  }

  // print sticks
  for(int i=0; i<ns; i++) 
    if (S[i]->type == T_STICK0) {
      thisti = (stick*) S[i];
      if (NULL == thisti->dadlink) {
        thisti->p1 = 0; thisti->p2 = 1;
      }
      thisti->sprint(buf, 200);
      out += buf;
  }

  // print neurons attached
  for(int i=0; i<ns; i++)
    if (T_NEURON0 == S[i]->type) {
      S[i]->sprint(buf, 200);
      out += buf;
      thneu = (neuron*) S[i];

      // print its links
      for(int k=0; k< thneu->nolink; k++) {
        thneu->links[k]->sprint(buf, 200);
        out += buf;
      }
  }
}


void Organism::to1(sstring &out)
{
  delete tmp;
  tmp = new stick(-1, NULL, 0, 1.0f, 0, 0);
  //out = "/*1*/ ";	// no version
  to1rec(0, out);
}


void Organism::to1rec(int sti, sstring &out)
{
  int i, j, ccount;
  stick * thisti;
  neuron * thneu;
  char buf[200];

  if (sti>=ns) return;

  if (T_STICK0 != S[sti]->type) return;

  thisti = (stick*) S[sti];
  if (NULL != thisti->dadlink)  *tmp = *((stick*)thisti->dadlink);
  // adjust length
  length_adj( &(tmp->len) );
  // adjust curvedness
  curved_adj( &(tmp->curved) );
  while (tmp->len > thisti->len) {
    length_dec( &(tmp->len) );
    out += "l";
  }
  while (tmp->len < thisti->len) {
    length_inc( &(tmp->len) );
    out += "L";
  }
  while (tmp->curved > thisti->curved) {
    curved_dec( &(tmp->curved) );
    out += "c";
  }
  while (tmp->curved < thisti->curved) {
    curved_inc( &(tmp->curved) );
    out += "C";
  }
  while (thisti->rolling > 0.0f) {
    rolling_dec( &(thisti->rolling) );
    out += "R";
  }
  while (thisti->rolling < 0.0f) {
    rolling_inc( &(thisti->rolling) );
    out += "r";
  }

  // output X for this stick
  out += "X";

  // neurons attached to it
  for (i=0; i<ns; i++)
    if (S[i]->type == T_NEURON0) {
      if (S[i]->dadlink == thisti) {
        thneu = (neuron*) S[i];
        out += "[";
        // ctrl
        if (1 == thneu->ctrl) out += "@";
        if (2 == thneu->ctrl) out += "|";
        // links
        for (j=0; j<thneu->nolink; j++) {
          if (j) out += ",";
          if (NULL == thneu->links[j]->from) {
            // sensory
            if (1 == thneu->links[j]->t) out += "*";
            if (2 == thneu->links[j]->t) out += "G";
          } else {
            sprintf(buf, "%d", thneu->links[j]->from->name - thneu->name);
            out += buf;
          }
          out += ":";
          // weight
          sprintf(buf, "%g", thneu->links[j]->w );
          out += buf;
        }
        out += "]";
    }
  }

  // sticks connected to it
  if (thisti->commacount>=2)
    out += "(";

  ccount=1;
  for (i=0; i<ns; i++)
   if (S[i]->type == T_STICK0)
    if (S[i]->dadlink == thisti) {
      while (ccount < ((stick*)S[i])->anglepos) {
        ccount++;
        out += ",";
      }
      to1rec(i, out);
  }
  while (ccount < thisti->commacount) {
    ccount++;
    out += ",";
  }

  if (thisti->commacount >= 2)
    out += ")";
}


// do final adjustments
void Organism::adjust() 
{
  int i, nsti, nneu;

  // renumber sticks and neurons, so they are 0,1,... in order
  //  of apparence.
  nsti = 0;
  nneu = 0;
  for(i=0; i<ns; i++) {
    if (T_STICK0 == S[i]->type) {
      S[i]->name = nsti;
      nsti++;
    }
    if (T_NEURON0 == S[i]->type) {
      S[i]->name = nneu;
      nneu++;
    }
  }

  // traverse sticks and set rotation matrixes
  adjustrec(NULL);
}


void Organism::adjustrec(stick * ndad)
{
  int i, childcnt;
  stick * thisti;
  float rotangl;
  matrix33 rot;

  // count children of dad
  childcnt = 0;
  if (NULL!=ndad) {
    for(i=0; i<ns; i++) {
      if (T_STICK0 == S[i]->type) 
        if (S[i]->dadlink == ndad)
          childcnt++;
    }
    ndad->childcount = childcnt;
  }
  // process children
  for(i=0; i<ns; i++)
    if (T_STICK0 == S[i]->type) {
      thisti = (stick*) S[i];
      if (thisti->dadlink == ndad) {
        if (ndad!=NULL) {
          thisti->firstend = ndad->lastend;
          rot = matrix33();
          // rotation due to rolling
          rot = rot * matrix33(yOz, ndad->rolling);
          rotangl = (thisti->anglepos * 1.0f/(ndad->commacount+1) - 0.5f) 
           * M_PI * 2.0f ;
          //DB( printf("rotang = %g\n", rotangl); )
          rot = rot * matrix33(xOy, rotangl);
          // rotation due to curvedness
          rot = rot * matrix33(xOy, ndad->curved);
          // rotation relative to parent stick
          thisti->OM = rot * thisti->OM;
          // rotation in world coordinates
          thisti->OM =  ndad->OM * thisti->OM;
          thisti->mz = ndad->mz / ndad->childcount; 
        } else {
          thisti->firstend = Vector(0,0,0);
          thisti->mz = 1;
        }
        thisti->lastend = thisti->firstend + 
          thisti->OM * (Vector(1,0,0)*thisti->len);
        adjustrec(thisti);
      }
    }
}


int scanrec(char * s, char stopchar)
{
  unsigned i;
  //DB( printf("    scan('%s', '%c')\n", s, stopchar); )
  for(i=0; i<strlen(s); i++) {
    if (s[i] == stopchar) return i;
    if (s[i] == '(') i += 1+scanrec(s+i+1, ')');
    if (s[i] == '<') i += 1+scanrec(s+i+1, '>');
    if (s[i] == '#') i += 1+scanrec(s+i+1, '>');
  }
  return i;
}

