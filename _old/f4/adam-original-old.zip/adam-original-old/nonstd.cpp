#include "nonstd.h"
#include <stdio.h>
#include <string.h>


void FramMessage(char* clas, char* method, char* message, int prio)
{
  fprintf(stderr, "%s::%s(): %s ", clas, method, message);
  if (0==prio) fprintf(stderr, "(info)");
  if (1==prio) fprintf(stderr, "(warning)");
  if (2==prio) fprintf(stderr, "(error)");
  if (3==prio) fprintf(stderr, "(critical error)");
  fprintf(stderr, "\n");
  if (3==prio) exit(-1);
}


//genkonwmanagerObj genkonwmanager;

// this is from Maciej
char genkonwmanager::wersjagenow(char *geno)
{
   if ((geno[0]=='/')&&strchr("*/",geno[1])) return( geno[2] );
   return '1';
}


// this is from Maciej
char * genkonwmanager::ominkomentarz(char *geno)
{
   char *t=geno,*t2;
   if (t[0]!='/') return geno;
   if (t[1]=='*')
   {
      while ((t2=strchr(t+1,'*')) != NULL)
        if (t2[1]=='/') return t2+2; else t=t2+1;
      return t+strlen(t);
   } else if (t[1]=='/')
   {
      if ((t2=strchr(t+1,'\n'))) return t2+1;
      return t+strlen(t);
   } else return geno;
}   
