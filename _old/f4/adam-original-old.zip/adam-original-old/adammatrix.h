/*
 *  matrix.h - matrix utilities
 *  first created: 1999.09.24.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.

 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#ifndef MATRIX_H
#define MATRIX_H

#include "adamvector.h"
#include "sstring.h"

typedef enum 
{ 
   xOy, xOz, yOz
} XYZplanes;

class matrix33
{
  public:
	float  a11, a12, a13;
	float  a21, a22, a23;
	float  a31, a32, a33;

    // unit matrix
	inline matrix33();
	// rotation matrix in a given cartesian plane
	inline matrix33(XYZplanes plane, float angle);
	// det of a matrix
	inline float det() const;
	// multiplication of a matrix by a matrix
        inline matrix33 operator*(const matrix33& m) const;
	// multiplication of a matrix by a vector
	inline Vector operator*(const Vector& v) const;
	// inverse matrix
	inline matrix33 inverse() const;

	void printox(sstring &out) const;
};



matrix33::matrix33()
{
	a11 = 1.0f;  a12 = 0.0f;  a13 = 0.0f;
	a21 = 0.0f;  a22 = 1.0f;  a23 = 0.0f;
	a31 = 0.0f;  a32 = 0.0f;  a33 = 1.0f;
}

matrix33::matrix33(XYZplanes plane, float angle)
{
	switch(plane) {
	case xOy:
		a11 = (float)cos(angle); a12 = (float)-sin(angle); a13 = 0.0f;
		a21 = (float)sin(angle); a22 = (float)cos(angle);  a23 = 0.0f;
		a31 =        0.0f;       a32 =        0.0f;        a33 = 1.0f;
		break;
	case xOz:
		a11 = (float)cos(angle); a12 = 0.0f; a13 = (float)-sin(angle);
		a21 =        0.0f;       a22 = 1.0f; a23 =        0.0f;
		a31 = (float)sin(angle); a32 = 0.0f; a33 = (float)cos(angle);
		break;
	case yOz:
		a11 = 1.0f;  a12 =        0.0f;       a13 =        0.0f;
		a21 = 0.0f;  a22 = (float)cos(angle); a23 = (float)-sin(angle);
		a31 = 0.0f;  a32 = (float)sin(angle); a33 = (float)cos(angle);
		break;
	}
}

float matrix33::det() const
{
   return
	    a11 * a22 * a33
	  + a21 * a32 * a13
	  + a12 * a23 * a31
	  - a31 * a22 * a13
	  - a21 * a12 * a33
	  - a32 * a23 * a11;
}

matrix33 matrix33::operator*(const matrix33& m) const
{
   matrix33 ret;
   ret.a11 = a11 * m.a11 + a12 * m.a21 + a13 * m.a31;
   ret.a12 = a11 * m.a12 + a12 * m.a22 + a13 * m.a32;
   ret.a13 = a11 * m.a13 + a12 * m.a23 + a13 * m.a33;
   ret.a21 = a21 * m.a11 + a22 * m.a21 + a23 * m.a31;
   ret.a22 = a21 * m.a12 + a22 * m.a22 + a23 * m.a32;
   ret.a23 = a21 * m.a13 + a22 * m.a23 + a23 * m.a33;
   ret.a31 = a31 * m.a11 + a32 * m.a21 + a33 * m.a31;
   ret.a32 = a31 * m.a12 + a32 * m.a22 + a33 * m.a32;
   ret.a33 = a31 * m.a13 + a32 * m.a23 + a33 * m.a33;
   return ret;
}

Vector matrix33::operator*(const Vector& v) const
{
   Vector ret;
   ret.x = a11 * v.x + a12 * v.y + a13 * v.z;
   ret.y = a21 * v.x + a22 * v.y + a23 * v.z;
   ret.z = a31 * v.x + a32 * v.y + a33 * v.z;
   return ret;
}

matrix33 matrix33::inverse() const
{
   matrix33 ret;
   float det = this->det();
   if (det==0) return ret;
   ret.a11 =  (a22 * a33 - a23 * a32) / det;
   ret.a12 = -(a12 * a33 - a13 * a32) / det;
   ret.a13 =  (a12 * a23 - a13 * a22) / det;
   ret.a21 = -(a21 * a33 - a23 * a31) / det;
   ret.a22 =  (a11 * a33 - a13 * a31) / det;
   ret.a23 = -(a11 * a23 - a13 * a21) / det;
   ret.a31 =  (a21 * a32 - a22 * a31) / det;
   ret.a32 = -(a11 * a32 - a12 * a31) / det;
   ret.a33 =  (a11 * a22 - a12 * a21) / det;
   return ret;
}

#endif
