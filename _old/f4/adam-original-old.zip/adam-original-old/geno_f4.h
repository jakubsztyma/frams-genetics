/*
 *  geno_f4.h - f4 genotype functions.
 *  2000.6.28.  1999.11.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#ifndef GENO_F4_H
#define GENO_F4_H


#include <stdio.h>
#include "adamgenos.h"
#include "adammatrix.h"
#include "sstring.h"
#include "nonstd.h"
#ifdef MAIN_FRAMSTICKS
#include "genman.h"
#endif

// convert from f4 (to f0 or f1)
int Convert_f4(char * in, int outformat, sstring &out);
// convert f4 geno to f0, f1
int Convert_f4_to_f0(char * in, sstring &out);
int Convert_f4_to_f1(char * in, sstring &out);


class f4node;   // later
class cells4;	// later


// f4 genotype management
class TGeno_f4: public TGeno_fx
{
public:
  TGeno_f4();
  int Validate(char *&);
    // returns error position (1-based), GENOPER_OKwhen geno is OK,
    // GENOPER_REPAIR if errors were fixed
  int Check(char *);
    // returns error position (1-based), GENOPER_OKwhen geno is OK,
    // GENOPER_REPAIR if errors and validation is possible
  int Mutate(char *& g, float &chg);
    // returns GENOPER_OK or GENOPER_OPFAIL
    // chg: fraction of changed genes in child (from 0 to 1)
  int CrossOver(char *&g1, char *&g2, float& chg1, float& chg2);
    // returns GENOPER_OK or GENOPER_OPFAIL
    // chg1: fraction of parent1 genes in child1 (parent2 has the rest)
    // chg2: fraction of parent2 genes in child2 (parent1 has the rest)
  float Similarity(char*,char*); //0..1 lub -1 jesli zly format
    // returns normalized similarity of genotypes (1: identical, 0: different)
  unsigned long Style(char *g, int pos); 
    // returns Style (and validity) of the genotype char g[pos]. Assume white background.
  // parameters
  #ifdef MAIN_FRAMSTICKS
    param  par;
  #endif
  // mutation probability parameters
  double mut1add, mut1del;
  double mutadd2div, mutadd2link, mutadd2rep;
//  param  par;
protected:
  int  ValidateRec(f4node * geno, int retrycount);
  int  MutateOne(f4node *& g, float &chg);
  void linkNodeMakeRandom(f4node * nn);
  void linkNodeChangeRandom(f4node * nn);
  void repeatNodeChangeRandom(f4node * nn);
  int  MutateOneValid(f4node * &g, float &chg);
  int  CrossOverOne(f4node *g1, f4node *g2, float chg);
    // returns GENOPER_OK or GENOPER_OPFAIL
    // chg: fraction of parent1 genes in child (in g1) (parent2 has the rest)
};


// an abstract cell type, extension of part/stick -- for developmental encoding
class cell4: public attrPart {
public:
  cell4(cells4 * nO, int nname, f4node * ngeno, f4node * ngcur,
    attrPart * ndad, int nangle, float nlen, float ncurv, float ntwist);
  virtual ~cell4();
  virtual void defAttrs(void) { };
  virtual void updateB4print(void) { };

  int onestep();	// execute one simulation step (till a division)

  stick  * sti;
  neuron * neu;
  cells4 * org;		// uplink to organism
  f4node * genot;	// genotype
  f4node * gcur;        // current genotype execution pointer
  int      active;      // whether development is still active
  f4node * repet_node;  // ptr to repetition code
  int      repet_count; // repetition counter
};                     


// a collection of cells, like Organism, for developmental encoding
#define MAX4CELLS 100
class cells4 {
public:
       cells4(f4node * fullgenome, int nrepair);
       ~cells4();
  int  onestep();	// simulate all parts for one step
  int  simulate();	// simulate development, return error (0 for ok)
  void addCell(cell4 * newcell);

  // for error reporting / genotype fixing
  int  geterror() { return error;};
  int  geterrorpos() { return errorpos;};
  void setError(int nerrpos);
  void setRepairRemove(int nerrpos, f4node * rem);
  int  setRepairInsert(int nerrpos, f4node * parent, f4node * insert);
  void repairGeno(f4node * geno, int whichchild);

  // the cells
  cell4 * C[MAX4CELLS];
  int nc;
  
private:
  // for error reporting / genotype fixing
  int repair;
  int error;
  int errorpos;
  f4node * repair_remove;
  f4node * repair_parent;
  f4node * repair_insert;
};                             


// to organize a f4 genotype in a tree structure
class f4node {
public:
  char     name;	// one-letter 'name'
  f4node * parent;	// parent link, or NULL
  f4node * child;	// child, or NULL
  f4node * child2;	// second child, or NULL
  int      pos;         // original position in string
  int      i1;		// internal int  parameter1
  long     l1;		// internal long parameter1
  float    f1;		// internal float parameter1

           f4node();
           f4node(char nname, f4node * nparent, int npos);
           ~f4node();
  int      addChild(f4node * nchi);
  int      removeChild(f4node * nchi);
  int      childCount(void);	// return no of children, 0, 1, or 2
  int      count(void);	// return no of nodes (recursive)
  f4node * ordNode(int n);	// returns the nth subnode (0-)
  f4node * randomNode(void);	// returns a random subnode
  f4node * randomNodeWithSize(int min, int max);	// returns a random subnode with given size
  void     sprintAdj(char *& buf);	// print recursively
  f4node * duplicate();         // create duplicate copy. recursive.
  void     destroy();	// release memory. recursive.
private:
  void     sprint(sstring & out);	// print recursively
};

// convert f4 geno string to tree structure (internal)
f4node * processf4(char * geno);
int processf4rec(char * genot, unsigned pos0, f4node * parent);


#endif

