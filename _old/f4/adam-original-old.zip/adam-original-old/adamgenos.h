/*
 *  genos.h - genotype conversion utilities.
 *  2000.6.14.  1999.11.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.

 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */
#ifndef GENOS_H
#define GENOS_H

#include <stdio.h>
#include "adamvector.h"
#include "adammatrix.h"
#include "sstring.h"
#include "nonstd.h"


// f2->f0
// if it is impossible to convert "in" into format "outformat",
// function returns 0. Else it fills "out".
// { sstring x; if (konwertujgenotyp("blabla",'0',x)) ... }
#ifndef MAIN_FRAMSTICKS
  int geno_conv(char * in, int outformat, sstring &out);
#endif // MAIN_FRAMSTICKS

// from specific types:
int Convert_f1(char * in, int outformat, sstring &out);
int Convert_f1_to_f0(char * in, sstring &out);


// cell types
#define T_UNDIFF   0
#define T_STICK0   1
#define T_NEURON0  2
#define T_UNDIFF4 40
#define T_STICK4  41
#define T_NEURON4 42
#define T_UNDIFF5 50
#define T_STICK5  51
#define T_NEURON5 52

// length increase/decrease for "l" and "L"
#define LEN_MAX 3.5f
void length_dec(float * lenv);
void length_inc(float * lenv);
void length_adj(float * lenv);
// curvedness
void curved_dec(float * v);
void curved_inc(float * v);
void curved_adj(float * v);
// rolling (one-time)
void rolling_dec(float * v);
void rolling_inc(float * v);


class Organism;


// an abstract attribute
class absAttribute {
public:
               absAttribute(char * nname);
  virtual      ~absAttribute();
  char *       name;  // name, like "x"
  virtual void reset() = 0;       // reset value to default
  virtual int  different() = 0;   // check if different from default
  virtual void sprint(char * buf) = 0;
};

// an abstract float attribute
class floatAttribute: public absAttribute {
public:
               floatAttribute(char * nname, float ndefval, float * nval);
  float        defval;
  float *      val;
  virtual void reset() { *val = defval; };
  virtual int  different() { return (*val!=defval); };
  virtual void sprint(char * buf);
};

// an abstract long attribute
class longAttribute: public absAttribute {
public:
               longAttribute(char * nname, long ndefval, long * nval);
  long         defval;
  long *       val;
  virtual void reset() { *val = defval; };
  virtual int  different() { return (*val!=defval); };
  virtual void sprint(char * buf);
};

#define      MAXATTR 30
class attribObject {
public:
               attribObject(char * nname);
  virtual      ~attribObject();
  virtual void defAttrs(void) = 0;
          void removeAttrs();
  void         addFloatAttr(char * nname, float ndefval, float * nval);
  void         addLongAttr (char * nname, long  ndefval, long  * nval);
  void         reset(void);
  virtual void updateB4print(void) = 0;
  void         sprint(char * buf, int len);
               // copy operator
  virtual void operator=(const attribObject & o);

  char *       f0name;
  int          nattr;
  absAttribute * A[MAXATTR];
};


// body part with attributes
class attrPart: public attribObject {
public:
               attrPart(int nname, char * f0name, int ntype, 
                        Organism * norg, attrPart * ndad);
DB(  virtual void print() { printf(" UNDIFF! "); }; )

  int          name;     // name (number)
  int          type;     // type
  Organism *   org;      // uplink to organism
  attrPart *   dadlink;  // link to parent cell
};


// an endpoint
class endpoint: public attribObject
{
public:
               endpoint();
  virtual void defAttrs(void);
  virtual void updateB4print(void) { };
  int    ordno, visitq, outputq, count;
  Vector sumpos;
  float x, y, z, m, vol, fr, ing;
};


// yes, this is the stick
class stick: public attrPart {
public:
               stick(void);
               stick(int nname, attrPart * ndad, int nangle, 
                float nlen, float ncurv, float ntwist);
               stick(int nname, stick * ndad, int nangle);
  virtual void defAttrs(void);
  virtual void updateB4print(void);
DB(  virtual void print(); )

  int          anglepos;      // number of position within dad's children (,)
  int          commacount;    // number of postitions at lastend
  int          childcount;    // number of children
  float        len;           // length ('L')
  float        curved;        // curvedness ('C')
  float        twist;         // twisting ('Q')
  float        rolling;       // rolling angle ('R')
  Vector       firstend;      // coord.s of first end (connects to parent)
  Vector       lastend;       // last end
  matrix33     OM;            // rotation matrix
  float        mz;            // freedom in z
  long         p1, p2;
  float        m, as, st;
};


class nlink;

// neuron
#define      MAXINPUTS 100
class neuron: public attrPart {
public:
               neuron(void);
               neuron(int nname, attrPart * ndad);
  virtual      ~neuron(void);
  int          addlink(neuron * nfrom, float nw, int nt);
  virtual void defAttrs(void);
  virtual void updateB4print(void);
DB(  virtual void print(); )

  long         est;
  // ctrl: 0: nothing; 1: @; 2: |
  long         ctrl;
  float        in;
  float        fo;
  long         si;		// sigma value
  nlink *      links[MAXINPUTS];
  int          nolink;
};

  
// an input link to a neuron
class nlink: public attribObject {
public:
               nlink(neuron * nfrom, neuron * nto);
  virtual void defAttrs(void);
  virtual void updateB4print(void);
  neuron *     to;
  neuron *     from;
  long         n;
  // type: 0: input, 1: '*'; 2: 'G'
  long         t;
  float        w;
  long         conn;
};

#ifdef MAIN_FRAMSTICKS
  #include "genman.h"	// fror GENOS_ defs
#endif

class f4node;

// an organism is a collection of parts (sticks, etc)
#define MAXST 1000
class Organism {
public:
      Organism();
      ~Organism();
  // build fs. return GENOPER_OK, or some error
  int buildfrom1(char * s);	// build it from f1 genotype
  int buildfrom4(char * s);	// build it from f4 genotype
  int buildfrom4(f4node * g, int repair);	// build it from f4 genotype
 #ifndef MAIN_FRAMSTICKS
  int buildfrom5(char * s);	// build it from f5 genotype
 #endif
				// from f0 it's not possible
  void to0(sstring &out);	// output to f0 format
  void to1(sstring &out);	// output to f1 format, approximation
  int  geterror() { return error; };
  int  geterrorpos() { return errorpos; };
  
DB(  void print(); )            // print out (list of parts)
  void empty();			// inititalize to empty
  void add(attrPart * s);	// add a part
private:
  attrPart * S[MAXST];		// parts
  int ns;			// and their number
  stick *  tmp;
  int b1_Xcount;
  int error;
  int errorpos;

  int parse1rec
    (char * s, stick * dadlink, int anglepos, char stop1, char stop2);  

  void to1rec(int sti, sstring &out);
  void adjust();
  void adjustrec(stick * mdad);	// called by adjust
  int  seterror() { error=GENOPER_OPFAIL; return 0; };
};


int scanrec(char * s, char stopchar);


#endif


