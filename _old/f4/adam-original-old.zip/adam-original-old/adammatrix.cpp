/*
 *  adammatrix.cpp - matrix utilities.
 *  2000.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#include "adammatrix.h"


void matrix33::printox(sstring &out) const
{
  char buf[100];
  sprintf(buf, "oxx:%g\noxy:%g\noxz:%g\n", a11, a12, a13);
  out += buf;
  sprintf(buf, "oyx:%g\noyy:%g\noyz:%g\n", a21, a22, a23);
  out += buf;
  sprintf(buf, "ozx:%g\nozy:%g\nozz:%g\n", a31, a32, a33);
  out += buf;
}

