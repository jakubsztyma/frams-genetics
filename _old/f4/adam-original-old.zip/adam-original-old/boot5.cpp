/*
 *  boot5.cpp - bootstrap evolution using f5 genotype.
 *  2000.3.27.  2000.1.21.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */

#define MAXPOPSIZE 30
//#define MAXFIT 125
#define MAXFIT 250
#define OUTDIR "pop52"
#define INFILE  "pop-in.txt"


#include <stdio.h>
#include "adamvector.h"
#include "adammatrix.h"
#include "sstring.h"
#include "nonstd.h"
//#include "genos.h"
#include "geno_f4.h"
#include "geno_f5.h"


class indiv {
public:
  indiv();
  indiv(FILE * f);
  float computeFit();
  void  anal();
  Rules * R;
  float fit;
};
char buf[5000];

indiv::indiv()
{
  // create a new random genotype
  R = new Rules(35, &commonSeed);
  computeFit();
}


indiv::indiv(FILE * f)
{
  char c;
  int pos=0;
  // read genotype
  // scan for first "
  do {
    fscanf(f, "%c", &c);
  } while (c!='"');
  // read genot
  while (1) {
    fscanf(f, "%c", &c);
    if (c=='"') break;
    buf[pos]=c; pos++; buf[pos]=0;
  }
  R = new Rules(buf);
  computeFit();
}


float indiv::computeFit()
{
  // build organism and get fitness
  Organism5 * Org = new Organism5(R);
  Org->simulate();
  sstring A;
  Org->write(stdout);
  Org->to0(A);
  fit = Org->fit();
  delete Org;
  return fit;
}


void indiv::anal()
{
  R->write(stdout);
  Organism5 * Org = new Organism5(R);
  Org->simulate();
  Org->write(stdout);
  sstring A;
  Org->to0(A);
  printf("f0:\n%s\n", (char*)A );
}


indiv * P[MAXPOPSIZE];
int order[MAXPOPSIZE];
int np = MAXPOPSIZE;


void printSumm()
{
  int i;
  for (i=0; i<np; i++)
    printf("%2d  fit %.2f\n", i, P[i]->fit);
  printf("\n");
}


void save(long t)
{
  int i;
  FILE * f;
  char fn[100];

  sprintf(fn, OUTDIR"/%ld.txt", t);
  f = fopen(fn, "w");
  fprintf(f, "%d\n\n", np);

  // save f0 of best
  sstring A;
  Organism5 * Org = new Organism5( P[order[0]]->R );
  Org->simulate();
  Org->to0(A);
  fprintf(f, "%s\n", (char*)A);

  for (i=0; i<np; i++) {
    fprintf(f, "# org %d fit %.3f\n", i, P[order[i]]->fit);
    P[order[i]]->R->write(buf);
    fprintf(f, "\"%s\"\n\n", buf );
  }

  fclose(f);
}


void sort()
{
  int i, j, tmp;
  for (i=0; i<np-1; i++) 
    for (j=i+1; j<np; j++)
      if (P[order[i]]->fit <= P[order[j]]->fit) {
        tmp=order[i]; order[i]=order[j]; order[j]=tmp;
  }
}


int mutate(int idx1)
{
  Rules * R2 = new Rules( P[order[idx1]]->R );
  R2->mutate(&commonSeed);
  // put it in last pos
  P[order[np-1]]->R = R2;
  float newfit = P[order[np-1]]->computeFit();
  printf("newfit %.2f\n", newfit);
  return 0;
}


void evolve()
{
  long t=0l, stopt=10000;
  int idx;
  float maxfit;
  while (1) {
    sort();
    maxfit = P[order[0]]->fit;
    printf("%ld maxfit %.2f\n", t, maxfit);
    if (maxfit>=MAXFIT) {
      stopt = t+100;
      save(t);
      break;
    }
    idx = (int)(8.0f*myRand(&commonSeed));
    mutate(idx);
    t++;
    if (t>stopt) break;
    if (0 == (t%10)) {
      save(t);
    }
  }
}


int main()
{
  int i;
  FILE * f1;

  commonSeed = 2l;
  f1 = fopen(INFILE, "r");

  if (0) {
    P[0] = new indiv(f1);  
    P[0]->anal();  
    return 0;
  }

  // init or load
  if (1) {
    np = MAXPOPSIZE;
    for (i=0; i<np; i++) {
      P[i] = new indiv();
    }
  } else {
    fscanf(f1, "%d", &np);
    printf("loading %d inds\n", np);
    for (i=0; i<np; i++) {
      P[i] = new indiv(f1);
    }
  }
  fclose(f1);

  for (i=0; i<np; i++) 
    order[i]=i;
  sort();

  evolve();

  save(0);

  return 0;
}
