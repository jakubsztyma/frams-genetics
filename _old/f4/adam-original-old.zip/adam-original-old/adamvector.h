/*
 *  adamvector.h - vector utilities
 *  2000.7.
 *
 *  adamgenos - f4 format genotype conversions for FramSticks
 *  Copyright (C) 2000  Adam Rotaru-Varga
 *  adam_rotaru@altavista.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.

 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 */
#ifndef VECTOR_H_INCLUDED
#define VECTOR_H_INCLUDED

#include <stdio.h>
#include "sstring.h"

class Vector
{ 
   public:
       inline Vector(const Vector& v);
       inline Vector(float xMag, float yMag, float zMag);
       inline Vector();
       inline void   Set(float x, float y, float z);
       inline void   X(float value);
       inline void   Y(float value);
       inline void   Z(float value);
       inline float  X() const { return x; }
       inline float  Y() const { return y; }
       inline float  Z() const { return z; }
       inline void   Normalize();
       inline Vector Normalized() const;
       inline Vector UnitVector() const { return Normalized(); };
       inline float Magnitude() const;              // euclidean distance from origin
       inline float Magnitude2() const;             // suare of distance
       inline float Sum() const;                    // simple distance from origin
       inline float Order0Dist() { return x+y+z; }; // order-0 distance
       inline Vector Cross(const Vector& v) const;
       inline float Dot(const Vector& v) const;
       inline Vector AveragedWith(const Vector& v) const;
       inline float Distance(const Vector& v) const;
       inline float Distance2(const Vector& v) const;   // square of distance
       inline float DistanceToLine(float a, float b, float c, float d);
       inline int operator==(const Vector& v) const;     // equality (useless)
       inline int operator!=(const Vector& v) const;
       inline Vector  operator+(const Vector& v) const;  // vector addition
       inline Vector& operator+=(const Vector& v);
       inline Vector  operator-(const Vector& v) const;  // vector subtraction
       inline Vector& operator-=(const Vector& v);
       inline float  operator|(const Vector& v) const;  // dot-product
       inline Vector  operator*(const Vector& v) const;
       inline Vector& operator*=(const Vector& v);
       inline Vector  operator/(const Vector& v) const;
       inline Vector& operator/=(const Vector& v);
       inline Vector  operator*(const float factor) const;  // scaling
       inline Vector& operator*=(const float factor);
       inline Vector  operator/(const float factor) const;  // scaling (inverse)
       inline Vector& operator/=(const float factor);
       inline Vector operator-() const;
       inline float operator[](int i) const { return *(&x+i); };

       void   printpx(sstring &out) const;
       void   Rotate(float theta, const Vector& axis);
      
       float x, y, z; 
};



// inline functions must be declared in .h file
#include <math.h>

Vector::Vector(float xCoord, float yCoord, float zCoord) : 
   x(xCoord), y(yCoord), z(zCoord) 
{
};

Vector::Vector() : 
   x(0.0f), y(0.0f), z(0.0f)
{
};

Vector::Vector(const Vector& v) : 
   x(v.X()), y(v.Y()), z(v.Z())
{
};

void Vector::X(float value)
{
   x = value;
};

void Vector::Y(float value)
{
   y = value;
};

void Vector::Z(float value)
{
   z = value;
};

void Vector::Set(float xVal, float yVal, float zVal)
{
   x = xVal;
   y = yVal;
   z = zVal;
}

void Vector::Normalize()
{
   *this = this->UnitVector();
}

Vector Vector::operator+(const Vector& v) const
{
   Vector ret;
   ret.x = this->x + v.x;
   ret.y = this->y + v.y;
   ret.z = this->z + v.z;
   return ret;
}

Vector& Vector::operator+=(const Vector& v)
{
   x += v.x;
   y += v.y;
   z += v.z;
   return *this;
}

Vector Vector::operator-(const Vector& v) const
{
   Vector ret;
   ret.x = x - v.x;
   ret.y = y - v.y;
   ret.z = z - v.z;
   return ret;
}

Vector Vector::operator*(const Vector& v) const
{
   return Vector(x*v.x, y*v.y, z*v.z);
}

Vector& Vector::operator*=(const Vector& v)
{
   x *= v.x;
   y *= v.y;
   z *= v.z;
   return *this;
}

Vector Vector::operator/(const Vector& v) const
{
   return Vector(x/v.x, y/v.y, z/v.z);
}

Vector& Vector::operator/=(const Vector& v)
{
   x /= v.x;
   y /= v.y;
   z /= v.z;
   return *this;
}

float Vector::operator|(const Vector& v) const
{
   return this->Dot(v);
}

Vector& Vector::operator-=(const Vector& v)
{
   x -= v.x;
   y -= v.y;
   z -= v.z;
   return *this;
}

Vector Vector::operator*(const float factor) const
{
   return Vector(x*factor, y*factor, z*factor);
}

Vector& Vector::operator*=(const float factor) 
{
   x *= factor;
   y *= factor;
   z *= factor;
   return *this;
};

Vector Vector::operator/(const float factor) const
{
   return *this * (1.0f / factor);
}

Vector& Vector::operator/=(const float factor) 
{
   return *this *= (1.0f / factor);
};

Vector Vector::operator-() const
{
   return Vector(-x, -y, -z);
}

float Vector::Magnitude() const
{
   return float(sqrt(x*x + y*y + z*z));
};

float Vector::Magnitude2() const
{
   return x*x + y*y + z*z;
};


float Vector::Sum() const
{
   return x+y+z;
}

int Vector::operator==(const Vector& p) const
{
   return (x==p.x && y==p.y && z==p.z);
};

int Vector::operator!=(const Vector& p) const
{
   return !(x==p.x && y==p.y && z==p.z);
};

Vector Vector::Normalized() const
{
   float mag = Magnitude();

   if (mag == 0.0f)
      return Vector(1.0f, 0.0f, 0.0f);
   else
      return *this / mag;
};

Vector Vector::Cross(const Vector& v) const
{
   return Vector(y*v.z - z*v.y, 
		 z*v.x - x*v.z, 
		 x*v.y - y*v.x);
}

float Vector::Dot(const Vector& v) const
{
   return x*v.x + y*v.y + z*v.z;
}

Vector Vector::AveragedWith(const Vector& v) const
{
   return (*this + v) * 0.5f;
}

float Vector::Distance(const Vector& v) const
{
   Vector delta = v - *this;
   return delta.Magnitude();
}

float Vector::Distance2(const Vector& v) const
{
   Vector delta = v - *this;
   return delta.x*delta.x + delta.y*delta.y + delta.z*delta.z;
}


#endif
